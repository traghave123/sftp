import logging

from netbox.views import generic
from . import filtersets, forms, tables
from django.shortcuts import render
from .models import CMU, CMUProfile, Gnodeb, CU, DU


#
# Gnodeb
#

class GnodebListView(generic.ObjectListView):
    queryset = Gnodeb.objects.all()
    table = tables.GnodebTable
    
class GnodebView(generic.ObjectView):
    queryset = Gnodeb.objects.all()

    def get_extra_context(self, request, instance):

        cu = CU.objects.filter(
            gnodeb=instance,
        )

        du = DU.objects.filter(
            gnodeb=instance,
        )

        return {
            'cu': cu,
            'du': du,
        }
    
class GnodebEditView(generic.ObjectEditView):
    queryset = Gnodeb.objects.all()
    form = forms.GnodebForm
    
class GnodebAddView(generic.ObjectEditView):
    queryset = Gnodeb.objects.all()
    form = forms.GnodebForm

class GnodebDeleteView(generic.ObjectDeleteView):
    queryset = Gnodeb.objects.all()

class GnodebBulkImportView(generic.BulkImportView):
    queryset = Gnodeb.objects.all()
    model_form = forms.GnodebCSVForm
    table = tables.GnodebTable

class GnodebBulkEditView(generic.BulkEditView):
    queryset = Gnodeb.objects.all()
    filterset = filtersets.GnodebFilterSet
    table = tables.GnodebTable
    form = forms.GnodebBulkEditForm

class GnodebBulkDeleteView(generic.BulkDeleteView):
    queryset = Gnodeb.objects.all()
    filterset = filtersets.GnodebFilterSet
    table = tables.GnodebTable
    
#
# CU
#
class CUListView(generic.ObjectListView):
    queryset = CU.objects.all()
    table = tables.CUTable

class CUView(generic.ObjectView):
    queryset = CU.objects.all()
    
class CUEditView(generic.ObjectEditView):
    queryset = CU.objects.all()
    form = forms.CUForm
    
class CUAddView(generic.ObjectEditView):
    queryset = CU.objects.all()
    form = forms.CUForm

class CUDeleteView(generic.ObjectDeleteView):
    queryset = CU.objects.all()

class CUBulkImportView(generic.BulkImportView):
    queryset = CU.objects.all()
    model_form = forms.CUCSVForm
    table = tables.CUTable

class CUBulkEditView(generic.BulkEditView):
    queryset = CU.objects.all()
    filterset = filtersets.CUFilterSet
    table = tables.CUTable
    form = forms.CUBulkEditForm

class CUBulkDeleteView(generic.BulkDeleteView):
    queryset = CU.objects.all()
    filterset = filtersets.CUFilterSet
    table = tables.CUTable

#
# DU
#
class DUListView(generic.ObjectListView):
    queryset = DU.objects.all()
    table = tables.DUTable

class DUView(generic.ObjectView):
    queryset = DU.objects.all()
    
class DUEditView(generic.ObjectEditView):
    queryset = DU.objects.all()
    form = forms.DUForm
    
class DUAddView(generic.ObjectEditView):
    queryset = DU.objects.all()
    form = forms.DUForm

class DUDeleteView(generic.ObjectDeleteView):
    queryset = DU.objects.all()

class DUBulkImportView(generic.BulkImportView):
    queryset = DU.objects.all()
    model_form = forms.DUCSVForm
    table = tables.DUTable

class DUBulkEditView(generic.BulkEditView):
    queryset = DU.objects.all()
    filterset = filtersets.DUFilterSet
    table = tables.DUTable
    form = forms.DUBulkEditForm

class DUBulkDeleteView(generic.BulkDeleteView):
    queryset = DU.objects.all()
    filterset = filtersets.DUFilterSet
    table = tables.DUTable

#
# CMUs
#

class CMUListView(generic.ObjectListView):
    queryset = CMU.objects.all()
    table = tables.CMUTable


class CMUView(generic.ObjectView):
    queryset = CMU.objects.all()


class CMUEditView(generic.ObjectEditView):
    queryset = CMU.objects.all()
    form = forms.CMUForm

class CMUAddView(generic.ObjectEditView):
    queryset = CMU.objects.all()
    form = forms.CMUForm

class CMUDeleteView(generic.ObjectDeleteView):
    queryset = CMU.objects.all()


class CMUBulkImportView(generic.BulkImportView):
    queryset = CMU.objects.all()
    model_form = forms.CMUCSVForm
    table = tables.CMUTable

class CMUBulkEditView(generic.BulkEditView):
    queryset = CMU.objects.all()
    filterset = filtersets.CMUFilterSet
    table = tables.CMUTable
    form = forms.CMUBulkEditForm

class CMUBulkDeleteView(generic.BulkDeleteView):
    queryset = CMU.objects.all()
    filterset = filtersets.CMUFilterSet
    table = tables.CMUTable



#
# CMU Profiles
#

class CMUProfileListView(generic.ObjectListView):
    queryset = CMUProfile.objects.all()
    table = tables.CMUProfileTable


class CMUProfileView(generic.ObjectView):
    queryset = CMUProfile.objects.all()


class CMUProfileEditView(generic.ObjectEditView):
    queryset = CMUProfile.objects.all()
    form = forms.CMUProfileForm

class CMUProfileAddView(generic.ObjectEditView):
    queryset = CMUProfile.objects.all()
    form = forms.CMUProfileForm

class CMUProfileDeleteView(generic.ObjectDeleteView):
    queryset = CMUProfile.objects.all()


class CMUProfileBulkImportView(generic.BulkImportView):
    queryset = CMUProfile.objects.all()
    model_form = forms.CMUProfileCSVForm
    table = tables.CMUProfileTable

class CMUProfileBulkEditView(generic.BulkEditView):
    queryset = CMUProfile.objects.all()
    filterset = filtersets.CMUProfileFilterSet
    table = tables.CMUProfileTable
    form = forms.CMUProfileBulkEditForm

class CMUProfileBulkDeleteView(generic.BulkDeleteView):
    queryset = CMUProfile.objects.all()
    filterset = filtersets.CMUProfileFilterSet
    table = tables.CMUProfileTable



