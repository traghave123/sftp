from django.core.exceptions import ValidationError
from django.core.validators import (MaxValueValidator, MinValueValidator)
from django.core.validators import (validate_ipv4_address)
from django.db import models
from django.urls import reverse
from netbox.models import NetBoxModel
from utilities_siteplanner.models import ImageRegistry
import taggit.managers
import uuid


__all__ = (
    'CMUProfile',
    'CMU',
    'Gnodeb',
    'CU',
    'DU',
    'GnodebConfig'
)

CMU_DEPLOY_MODES = (
    ('redundant','redundant'),
    ('simplex', 'simplex'),
)

CMU_VARIENT = (
    ('epc','EPC'),
    ('5gc', '5GC'),
)

SNMP_V3_AUTH_PROTO = (
    ('md5','MD5'),
    ('sha', 'SHA'),
)

SNMP_V3_PRIVACY_PROTO = (
    ('des','DES'),
    ('aes', 'AES'),
)

def validate_ipv4_custom(value):
    if '/' in value:
        ipaddr = value.split("/")[0]
        validate_ipv4_address(ipaddr)
    else:
        validate_ipv4_address(value)


class Gnodeb(NetBoxModel):
    """
    Represents a GNodeb instance
    """
    name = models.CharField(max_length=100, blank=False, null=False, unique=True, verbose_name='Name')
    description = models.CharField(max_length=100, blank=True, null=True, unique=False, verbose_name='Description')

    virtual_infrastructure = models.ForeignKey(
        to='nfvi_management.VirtualInfrastructure',
        on_delete=models.SET_NULL,
        related_name='gnodebclustergroup',
        blank=False,
        null=True,
        verbose_name='Edge location'
    )

    # cu_du_cluster = models.ForeignKey(
    #     to='virtualization.Cluster',
    #     on_delete=models.SET_NULL,
    #     related_name='gnodebcluster',
    #     blank=False,
    #     null=True,
    #     verbose_name='CU DU cluster'
    # )

    netact_instance_name = models.ForeignKey(
        to='dcim.Device',
        on_delete=models.SET_NULL,
        related_name='gnodebnetact',
        blank=False,
        null=True,
        verbose_name='NetAct instance'
    )

    tags = taggit.managers.TaggableManager(through='extras.TaggedItem', blank=True)
    
    class Meta:
        ordering = ['name']
        verbose_name = 'GNODEB'
        verbose_name_plural = 'GNODEBs'

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:nokia_siteplanner:gnodeb', args=[self.pk])

    def get_tags_as_list(self):
        return [str(tag) for tag in self.tags.names()]
          


#####################

class CU(NetBoxModel):
    """
    Represents a CU
    """
    name = models.CharField(max_length=100, blank=False, null=False, unique=True)
    description = models.CharField(max_length=100, blank=True, null=True, unique=True)
    namespace = models.CharField(max_length=100, blank=False, null=False, unique=False)

    cluster = models.ForeignKey(
        to='virtualization.Cluster',
        on_delete=models.SET_NULL,
        related_name='cucluster',
        blank=False,
        null=True,
        verbose_name='Cluster'
    )

    # cloud_id = models.CharField(max_length=100, blank=False, null=False, unique=False)
    configuration_software_id = models.CharField(max_length=100, blank=False, null=False, unique=False)
    release_name = models.CharField(max_length=100, blank=False, null=False, unique=False) 
    nerel_id = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name='NeRel id')
    secrets = models.JSONField(blank=True, null=True, verbose_name='Secrets')   
    vcu_profile_name = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name='vCU profile name')
    chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False)
    prerequisites_chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False)
    cluster_preparation_chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False)

    container_imageregistry = models.ForeignKey(
        to='utilities_siteplanner.ImageRegistry',
        on_delete=models.SET_NULL,
        related_name='gnodebCUImageregistry',
        blank=False,
        null=True
    )

    gnodeb = models.ForeignKey(
        to='nokia_siteplanner.Gnodeb',
        on_delete=models.PROTECT,
        related_name='cugnodebs',
        blank=False,
        null=True,
        verbose_name='GNODEB'
    )   

    class Meta:
        ordering = ['name']
        verbose_name = 'CU detail'
        verbose_name_plural = 'CU details'

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:nokia_siteplanner:cu', args=[self.pk])

    def validate_data(self):
        # Validate for clound account type name
        if self.name == '':
            raise ValidationError('Name must be provided for a GnodeB Configuration')
        
#####################

class DU(NetBoxModel):
    """
    Represents a DU
    """
    name = models.CharField(max_length=100, blank=False, null=False, unique=True)
    description = models.CharField(max_length=100, blank=True, null=True, unique=True)
    namespace = models.CharField(max_length=100, blank=False, null=False, unique=False)
    # cloud_id = models.CharField(max_length=100, blank=False, null=False, unique=False)

    cluster = models.ForeignKey(
        to='virtualization.Cluster',
        on_delete=models.SET_NULL,
        related_name='ducluster',
        blank=False,
        null=True,
        verbose_name='Cluster'
    )

    configuration_software_id = models.CharField(max_length=100, blank=False, null=False, unique=False) 
    release_name = models.CharField(max_length=100, blank=False, null=False, unique=False) 
    nerel_id = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name='NeRel id')
    secrets = models.JSONField(blank=True, null=True, verbose_name='Secrets') 
    vdu_profile_name = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name='vDU profile name')
    chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False)
    prerequisites_chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False)
    cluster_preparation_chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False)
    
    container_imageregistry = models.ForeignKey(
        to='utilities_siteplanner.ImageRegistry',
        on_delete=models.SET_NULL,
        related_name='gnodebDUImageregistry',
        blank=False,
        null=True
    )

    gnodeb = models.ForeignKey(
        to='nokia_siteplanner.Gnodeb',
        on_delete=models.PROTECT,
        related_name='dugnodebs',
        blank=False,
        null=True,
        verbose_name='GNODEB'
    )   
    
    nop_name = models.CharField(max_length=100, blank=False, null=False, unique=True, verbose_name='Name')
    nop_description = models.CharField(max_length=100, blank=True, null=True, unique=True, verbose_name='Description')
    nop_namespace = models.CharField(max_length=100, blank=False, null=False, unique=False,verbose_name='Namespace')
    nop_configuration_software_id = models.CharField(max_length=100, blank=False, null=False, unique=False,verbose_name='Configuration Software id') 
    nop_release_name = models.CharField(max_length=100, blank=False, null=False, unique=False,verbose_name='Release name') 
    nop_secrets = models.JSONField(blank=True, null=True, verbose_name='Secrets') 
    nop_vdu_profile_name = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name='NOP profile name')
    nop_chart_version = models.CharField(max_length=100, blank=False, null=False, unique=False,verbose_name='Chart version')
    
    nop_container_imageregistry = models.ForeignKey(
        to='utilities_siteplanner.ImageRegistry',
        on_delete=models.SET_NULL,
        related_name='gnodebNOPDUImageregistry',
        blank=False,
        null=True,
        verbose_name='Container registry'
    )

    class Meta:
        ordering = ['name']
        verbose_name = 'DU detail'
        verbose_name_plural = 'DU details'

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:nokia_siteplanner:du', args=[self.pk])

    def validate_data(self):
        # Validate for clound account type name
        if self.name == '':
            raise ValidationError('Name must be provided for a GnodeB Configuration')

class CMUProfile(NetBoxModel):
    """
    CMUProfile Model
    """

    name = models.CharField(max_length=64, blank=False, null=False, unique=True, verbose_name="Name")
    description = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Description")
    cmu_deployment_mode = models.CharField(max_length=32, blank=False, null=False, choices=CMU_DEPLOY_MODES, default='redundant', verbose_name="Deployment Mode")
    cmu_varient = models.CharField(max_length=32, blank=False, null=False, choices=CMU_VARIENT, default='epc', verbose_name="Varient")
    cmu_timezone = models.CharField(max_length=32, default="UTC", unique=False, verbose_name="Timezone")
    cmu_imageregistry = models.ForeignKey(to='utilities_siteplanner.ImageRegistry', on_delete=models.deletion.RESTRICT, related_name='cmuprofileimageregistry', blank=False, null=False, verbose_name="Image Registry Server")
    cmu_image_repository = models.CharField(max_length=128, blank=True, unique=False, verbose_name="Repository Path", help_text="Relative path to append with base url, Ex: cmu_images, Repo URL: repo-server:port/cmu_images")
    cmu_imageregistry_pullsecret = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="Registry Pull Secret", help_text="Existing pull secret name if already created")
    cmu_qcow_http_server = models.ForeignKey(to='utilities_siteplanner.HttpServer', on_delete=models.deletion.RESTRICT, related_name='cmuprofileqcowhttpserver', blank=False, null=False, verbose_name="QCOW Http Server")
    cmu_qcow_relative_path = models.CharField(max_length=128, blank=True, unique=False, verbose_name="QCOW Relative Path", help_text="Relative path to append with base url, Ex: cmu_qcow_images, Http URL: http://server-ip-address/cmu_qcow_images")

    cmu_bastion_server = models.ForeignKey(to='utilities_siteplanner.BastionServer', on_delete=models.deletion.RESTRICT, related_name='cmuprofilebastionserver', blank=False, null=False, verbose_name="Bastion Server", help_text="Used as ansible provisioning host")
    cmu_ext_ntp_ip_1 = models.CharField(max_length=32, blank=False, null=False, unique=False, verbose_name="External NTP Server 1")
    cmu_ext_ntp_ip_2 = models.CharField(max_length=32, blank=False, null=False, unique=False, verbose_name="External NTP Server 2")
    cmu_ext_nameserver_ip_list = models.CharField(max_length=128, blank=True, null=False, unique=False, verbose_name="External Nameserver IPs", help_text="Comma separated list of IP addresses")
    cmu_nsp_management_ip = models.CharField(max_length=64, validators=[validate_ipv4_custom], blank=False, null=False, unique=False, verbose_name="NSP Management IP", help_text="Example: 192.168.1.254")
    system_namespace = models.CharField(max_length=64, default="cmu-sys-gui", blank=True, null=False, unique=False, verbose_name="Namespace")
    system_service_account_name = models.CharField(max_length=64, default="cmu-sys-sa", blank=True, null=False, unique=False, verbose_name="Service Account")
    system_service_type = models.CharField(max_length=64, default="ClusterIP", blank=True, null=False, unique=False, verbose_name="Service Type")
    system_storage_class_name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Storage Class")
    system_image_name = models.CharField(max_length=64, default="cmu-system-pod", unique=False, verbose_name="Image Name")
    system_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Image Tag")

    gui_replica_count = models.PositiveSmallIntegerField(default=1, validators=[MinValueValidator(1)], blank=True, null=False, unique=False, verbose_name="Pod Replicas")
    gui_namespace = models.CharField(max_length=64, default="cmu-sys-gui", blank=True, null=False, unique=False, verbose_name="Namespace", help_text="Recommended to be same as system operator namespace")
    gui_storage_class_name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Storage Class")
    gui_service_account_name = models.CharField(max_length=64, default="cmu-gui-sa", blank=True, null=False, unique=False, verbose_name="Service Account")

    gui_cassandra_image_name = models.CharField(max_length=64, default="cassandra", unique=False, verbose_name="Cassandra Image Name")
    gui_cassandra_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Cassandra Image Tag")
    gui_cassandra_pod_cpu = models.PositiveSmallIntegerField(default=2000, validators=[MinValueValidator(2000)], blank=True, null=False, unique=False, verbose_name="Cassandra CPU(millicore)")
    gui_cassandra_pod_memory = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(10)], blank=True, null=False, unique=False, verbose_name="Cassandra Memory(GB)")
    gui_cassandra_pvc_size = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(10)], blank=True, null=False, unique=False, verbose_name="Cassandra PVC(GB)")

    gui_cmupfm_image_name = models.CharField(max_length=64, default="cmu_pfm", unique=False, verbose_name="Perf Monitor Image Name")
    gui_cmupfm_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Perf Monitor Image Tag")
    gui_cmupfm_pod_cpu = models.PositiveSmallIntegerField(default=500, validators=[MinValueValidator(500)], blank=True, null=False, unique=False, verbose_name="Perf Monitor CPU(millicore)")
    gui_cmupfm_pod_memory = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(10)], blank=True, null=False, verbose_name="Perf Monitor Memory(GB)")

    gui_consoles_image_name = models.CharField(max_length=64, default="cmu_consoles", unique=False, verbose_name="Console Image Name")
    gui_consoles_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Console Image Tag")

    gui_gui_image_name = models.CharField(max_length=64, default="cmu_gui", unique=False, verbose_name="GUI Image Name")
    gui_gui_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="GUI Image Tag")
    gui_gui_pvc_size = models.PositiveSmallIntegerField(default=5, validators=[MinValueValidator(5)], blank=True, null=False, unique=False, verbose_name="GUI PVC(GB)")

    gui_service_type = models.CharField(max_length=64, default="NodePort", blank=True, null=False, unique=False, verbose_name="Service Type")
    gui_https_node_port = models.PositiveBigIntegerField(default=30096, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https")
    gui_https_node_port_cmg = models.PositiveBigIntegerField(default=30097, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https Mobile Gateway")
    gui_https_node_port_cmm = models.PositiveBigIntegerField(default=30098, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https Mobility Manager")
    gui_https_node_port_cmgsec = models.PositiveBigIntegerField(default=30099, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https Mobile Gateway Secondary")

    oam_network_name = models.CharField(max_length=64, default="oam-network", blank=True, null=False, unique=False, verbose_name="Name")
    oam_network_cidr = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="192.168.100.0/24", blank=False, null=False, unique=False, verbose_name="CIDR", help_text="Miminum subnet mask /27")
    oam_network_gw_ip = models.CharField(max_length=32, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Gateway IP", help_text="Defaults to first IP address, Eg: 192.168.100.1")
    oam_network_start_ip = models.CharField(max_length=64, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Start IP Address", help_text="Defaults to second IP address, Eg: 192.168.100.2, Total 15 IPs will be consumed starting from this IP")
    oam_network_vlan_id = models.PositiveSmallIntegerField(default=563, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Vlan Id")
    oam_network_bridge = models.CharField(max_length=32, default="oam-bridge", blank=True, null=False, unique=False, verbose_name="Bridge")
    oam_network_bridge_nad = models.CharField(max_length=32, default="oam-bridge-nad", blank=True, null=False, unique=False, verbose_name="Bridge NAD")
    oam_network_rtable_id = models.PositiveSmallIntegerField(default=500, validators=[MinValueValidator(1), MaxValueValidator(5000)], blank=True, null=False, unique=False, verbose_name="Route Table Id")

    sig_network_cidr = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.1.1.0/24", blank=False, null=False, unique=False, verbose_name="CIDR", help_text="Miminum subnet mask /26")
    sig_network_gw_ip = models.CharField(max_length=32, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Gateway IP", help_text="Defaults to first IP address, Eg: 10.1.1.1")
    sig_network_start_ip = models.CharField(max_length=64, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Start IP Address", help_text="Defaults to second IP address, Eg: 10.1.1.2, Total 35 IPs will be consumed starting from this IP")
    sig_network_vlanid = models.PositiveSmallIntegerField(default=560, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Vlan Id")
    sig_network_bridge = models.CharField(max_length=32, default="cmu-br0", blank=True, null=False, unique=False, verbose_name="Bridge")
    sig_network_bridge_nad = models.CharField(max_length=32, default="sig-bridge-nad", blank=True, null=False, unique=False, verbose_name="Bridge NAD")

    snmp_v3_user = models.CharField(max_length=64, blank=False, null=False, default='privUserApp', verbose_name="User")
    snmp_v3_auth_password = models.CharField(max_length=64, blank=False, null=False, default='authUser', verbose_name="Auth Password")
    snmp_v3_auth_protocol = models.CharField(max_length=32, blank=True, null=False, choices=SNMP_V3_AUTH_PROTO, default='md5', verbose_name="Auth Protocol")
    snmp_v3_privacy_protocol = models.CharField(max_length=32, blank=True, null=False, choices=SNMP_V3_PRIVACY_PROTO, default='des', verbose_name="Privacy Protocol")


    cmg_name = models.CharField(max_length=64, default="UPF01", blank=True, null=False, unique=False, verbose_name="Name")
    cmg_namespace = models.CharField(max_length=64, default="cmu-cmg", blank=True, null=False, unique=False, verbose_name="Namespace")
    cmg_uuid = models.UUIDField(default=uuid.uuid4, blank=True, null=False, unique=False, verbose_name="UUID")
    cmg_autonomous_system_number = models.PositiveIntegerField(default=65001, validators=[MinValueValidator(64512), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Autonomous System Number")
    cmg_base_nodeport_range = models.PositiveIntegerField(default=31000, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Base Node Port Range")
    cmg_ssh_port = models.PositiveIntegerField(default=22, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="SSH Port")

    cmg_sys_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="192.168.250.1/32", blank=False, null=False, unique=False, verbose_name="System Loopback IP with Netmask", help_text="IP address with /32 mask")
    cmg_sys_loopback_vlanid = models.PositiveSmallIntegerField(default=564, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="System Loopback(DSF-1) Vlan Id")
    cmg_sig_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.20.0.1/32", blank=False, null=False, unique=False, verbose_name="SIG Loopback IP with Netmask", help_text="IP address with /32 mask")
    cmg_sig_loopback_vlanid = models.PositiveSmallIntegerField(default=565, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="SIG Loopback(DSF-2) Vlan Id")
    cmg_sig_loopback_mac_address = models.CharField(max_length=32, default="fe:ff:10:01:01:02", blank=True, null=False, unique=False, verbose_name="SIG Loopback MAC Address")

    cmg_lb_port1_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.0.1/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-1 IP with Netmask", help_text="IP address with /30 mask")
    cmg_lb_port1_vlanid = models.PositiveSmallIntegerField(default=561, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Loadbalancer Port-1 Vlan Id")
    cmg_lb_port2_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.1.1/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-2 IP with Netmask", help_text="IP address with /30 mask")
    cmg_lb_port2_vlanid = models.PositiveSmallIntegerField(default=562, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Loadbalancer Port-2 Vlan Id")

    cmg_sriov_enable_dpdk_vlan = models.BooleanField(default=False, verbose_name="SRIOV Enable DPDK Vlan")
    cmg_sriov_vf_pool_namespace = models.CharField(max_length=32, default="openshift.io", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool Namespace")
    cmg_sriov_vf_pool1_name = models.CharField(max_length=32, default="mlxnics1", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-1 Name")
    cmg_sriov_vf_pool1_trust = models.BooleanField(default=True, verbose_name="SRIOV VF Pool-1 Trust ON")
    cmg_sriov_vf_pool2_name = models.CharField(max_length=32, default="mlxnics2", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-2 Name")
    cmg_sriov_vf_pool2_trust = models.BooleanField(default=False, verbose_name="SRIOV VF Pool-2 Trust ON")
    cmg_apn_ip_pool = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.100.0.0/16", blank=True, null=False, unique=False, verbose_name="APN IP Pool")

    sec_cmg_name = models.CharField(max_length=64, default="SMF01", blank=True, null=False, unique=False, verbose_name="Name")
    sec_cmg_namespace = models.CharField(max_length=64, default="cmu-sec-cmg", blank=True, null=False, unique=False, verbose_name="Namespace")
    sec_cmg_uuid = models.UUIDField(default=uuid.uuid4, blank=True, null=False, unique=False, verbose_name="UUID")
    sec_cmg_base_nodeport_range = models.PositiveIntegerField(default=32000, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Base Node Port Range")
    sec_cmg_ssh_port = models.PositiveIntegerField(default=22, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="SSH Port")

    sec_cmg_sys_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="192.168.250.2/32", blank=False, null=False, unique=False, verbose_name="System Loopback IP with Netmask", help_text="IP address with /32 mask")
    sec_cmg_sys_loopback_vlanid = models.PositiveSmallIntegerField(default=566, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="System Loopback(DSF-1) Vlan Id")
    sec_cmg_sig_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.20.0.2/32", blank=False, null=False, unique=False, verbose_name="SIG Loopback IP with Netmask", help_text="IP address with /32 mask")
    sec_cmg_sig_loopback_vlanid = models.PositiveSmallIntegerField(default=567, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="SIG Loopback(DSF-2) Vlan Id")
    sec_cmg_lb_port1_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.0.2/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-1 IP with Netmask", help_text="IP address with /30 mask")
    sec_cmg_lb_port1_vlanid = models.PositiveSmallIntegerField(default=561, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-1 Vlan Id")
    sec_cmg_lb_port2_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.1.2/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-2 IP with Netmask", help_text="IP address with /30 mask")
    sec_cmg_lb_port2_vlanid = models.PositiveSmallIntegerField(default=562, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-2 Vlan Id")

    sec_cmg_sriov_vf_pool_namespace = models.CharField(max_length=32, default="openshift.io", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool Namespace")
    sec_cmg_sriov_vf_pool1_name = models.CharField(max_length=32, default="mlxnics1", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-1 Name")
    sec_cmg_sriov_vf_pool1_trust = models.BooleanField(default=True, verbose_name="SRIOV VF Pool-1 Trust ON")
    sec_cmg_sriov_vf_pool2_name = models.CharField(max_length=32, default="mlxnics2", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-2 Name")
    sec_cmg_sriov_vf_pool2_trust = models.BooleanField(default=False, verbose_name="SRIOV VF Pool-2 Trust ON")

    cmm_name = models.CharField(max_length=32, default="AMF01", blank=True, null=False, unique=False, verbose_name="Name")
    cmm_namespace = models.CharField(max_length=32, default="cmu-cmm", blank=True, null=False, unique=False, verbose_name="Namespace")
    cmm_uuid = models.UUIDField(default=uuid.uuid4, blank=True, null=False, unique=False, verbose_name="UUID")

    apc_name = models.CharField(max_length=32, default="APC", blank=True, null=False, unique=False, verbose_name="Name")
    apc_namespace = models.CharField(max_length=32, default="cmu-apc", blank=True, null=False, unique=False, verbose_name="Namespace")
    apc_spr_sync_enable = models.BooleanField(default=False, verbose_name="Enable SPR Synchronization")
    apc_spr_sync_remote_sap_sig_ip = models.CharField(max_length=32, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="SPR Remote SAP SIG IP", help_text="Eg: 192.0.2.3")

    class Meta:
        ordering = ['name']
        verbose_name = 'CMU Profile'
        verbose_name_plural = 'CMU Profiles'
        unique_together = {('name', 'system_tenant_id') }

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:nokia_siteplanner:cmuprofile', args=[self.pk])

    def validate_data(self):
        if self.name == '':
            raise ValidationError('Name must be provided for a CMU Profile')

    def clean(self):
        if self.system_namespace != self.gui_namespace:
            raise ValidationError('System Operator namespace should be same as GUI namespace')
        if self.snmp_v3_auth_password == "":
            raise ValidationError('Enter SNMP Auth Password')


class CMU(NetBoxModel):
    """
    CMU Model
    """

    name = models.CharField(max_length=64, blank=False, null=False, unique=True, verbose_name="Name")
    description = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Description")
    cmu_cluster = models.ForeignKey(to='virtualization.Cluster', on_delete=models.deletion.RESTRICT, related_name='cmucluster', blank=False, null=False, verbose_name="OCP Cluster")
    cmu_profile = models.ForeignKey(to='nokia_siteplanner.CMUProfile', on_delete=models.deletion.RESTRICT, related_name='cmuprofile', blank=True, null=True, verbose_name="Profile")
    cmu_deployment_mode = models.CharField(max_length=32, blank=False, null=False, choices=CMU_DEPLOY_MODES, default='redundant', verbose_name="Deployment Mode")
    cmu_varient = models.CharField(max_length=32, blank=False, null=False, choices=CMU_VARIENT, default='epc', verbose_name="Varient")
    cmu_timezone = models.CharField(max_length=32, default="UTC", unique=False, verbose_name="Timezone")
    cmu_imageregistry = models.ForeignKey(to='utilities_siteplanner.ImageRegistry', on_delete=models.deletion.RESTRICT, related_name='cmuimageregistry', blank=False, null=False, verbose_name="Image Registry Server")
    cmu_image_repository = models.CharField(max_length=128, blank=True, unique=False, verbose_name="Repository Path", help_text="Relative path to append with base url, Ex: cmu_images, Repo URL: repo-server:port/cmu_images")
    cmu_imageregistry_pullsecret = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="Registry Pull Secret", help_text="Existing pull secret name if already created")
    cmu_qcow_http_server = models.ForeignKey(to='utilities_siteplanner.HttpServer', on_delete=models.deletion.RESTRICT, related_name='cmuqcowhttpserver', blank=False, null=False, verbose_name="QCOW Http Server")
    cmu_qcow_relative_path = models.CharField(max_length=128, blank=True, unique=False, verbose_name="QCOW Relative Path", help_text="Relative path to append with base url, Ex: cmu_qcow_images, Http URL: http://server-ip-address/cmu_qcow_images")

    cmu_bastion_server = models.ForeignKey(to='utilities_siteplanner.BastionServer', on_delete=models.deletion.RESTRICT, related_name='cmubastionserver', blank=False, null=False, verbose_name="Bastion Server", help_text="Used as ansible provisioning host")
    cmu_ext_ntp_ip_1 = models.CharField(max_length=32, blank=False, null=False, unique=False, verbose_name="External NTP Server 1")
    cmu_ext_ntp_ip_2 = models.CharField(max_length=32, blank=False, null=False, unique=False, verbose_name="External NTP Server 2")
    cmu_ext_nameserver_ip_list = models.CharField(max_length=128, blank=True, null=False, unique=False, verbose_name="External Nameserver IPs", help_text="Comma separated list of IP addresses")
    cmu_nsp_management_ip = models.CharField(max_length=64, validators=[validate_ipv4_custom], blank=False, null=False, unique=False, verbose_name="NSP Management IP", help_text="Example: 192.168.1.254")
    system_namespace = models.CharField(max_length=64, default="cmu-sys-gui", blank=True, null=False, unique=False, verbose_name="Namespace")
    system_service_account_name = models.CharField(max_length=64, default="cmu-sys-sa", blank=True, null=False, unique=False, verbose_name="Service Account")
    system_service_type = models.CharField(max_length=64, default="ClusterIP", blank=True, null=False, unique=False, verbose_name="Service Type")
    system_storage_class_name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Storage Class")
    system_image_name = models.CharField(max_length=64, default="cmu-system-pod", unique=False, verbose_name="Image Name")
    system_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Image Tag")

    gui_replica_count = models.PositiveSmallIntegerField(default=1, validators=[MinValueValidator(1)], blank=True, null=False, unique=False, verbose_name="Pod Replicas")
    gui_namespace = models.CharField(max_length=64, default="cmu-sys-gui",  blank=True, null=False, unique=False, verbose_name="Namespace", help_text="Recommended to be same as system operator namespace")
    gui_storage_class_name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Storage Class")
    gui_service_account_name = models.CharField(max_length=64, default="cmu-gui-sa", blank=True, null=False, unique=False, verbose_name="Service Account")

    gui_cassandra_image_name = models.CharField(max_length=64, default="cassandra", unique=False, verbose_name="Cassandra Image Name")
    gui_cassandra_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Cassandra Image Tag")
    gui_cassandra_pod_cpu = models.PositiveSmallIntegerField(default=2000, validators=[MinValueValidator(2000)], blank=True, null=False, unique=False, verbose_name="Cassandra CPU(millicore)")
    gui_cassandra_pod_memory = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(10)], blank=True, null=False, unique=False, verbose_name="Cassandra Memory(GB)")
    gui_cassandra_pvc_size = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(10)], blank=True, null=False, unique=False, verbose_name="Cassandra PVC(GB)")

    gui_cmupfm_image_name = models.CharField(max_length=64, default="cmu_pfm", unique=False, verbose_name="Perf Monitor Image Name")
    gui_cmupfm_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Perf Monitor Image Tag")
    gui_cmupfm_pod_cpu = models.PositiveSmallIntegerField(default=500, validators=[MinValueValidator(500)], blank=True, null=False, unique=False, verbose_name="Perf Monitor CPU(millicore)")
    gui_cmupfm_pod_memory = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(10)], blank=True, null=False, verbose_name="Perf Monitor Memory(GB)")

    gui_consoles_image_name = models.CharField(max_length=64, default="cmu_consoles", unique=False, verbose_name="Console Image Name")
    gui_consoles_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="Console Image Tag")

    gui_gui_image_name = models.CharField(max_length=64, default="cmu_gui", unique=False, verbose_name="GUI Image Name")
    gui_gui_image_tag = models.CharField(max_length=32, default="23.0.R1", unique=False, verbose_name="GUI Image Tag")
    gui_gui_pvc_size = models.PositiveSmallIntegerField(default=5, validators=[MinValueValidator(5)], blank=True, null=False, unique=False, verbose_name="GUI PVC(GB)")

    gui_service_type = models.CharField(max_length=64, default="NodePort", blank=True, null=False, unique=False, verbose_name="Service Type")
    gui_https_node_port = models.PositiveBigIntegerField(default=30096, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https")
    gui_https_node_port_cmg = models.PositiveBigIntegerField(default=30097, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https Mobile Gateway")
    gui_https_node_port_cmm = models.PositiveBigIntegerField(default=30098, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https Mobility Manager")
    gui_https_node_port_cmgsec = models.PositiveBigIntegerField(default=30099, validators=[MinValueValidator(1025), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Https Mobile Gateway Secondary")

    oam_network_name = models.CharField(max_length=64, default="oam-network", blank=True, null=False, unique=False, verbose_name="Name")
    oam_network_cidr = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="192.168.100.0/24", blank=False, null=False, unique=False, verbose_name="CIDR", help_text="Miminum subnet mask /27")
    oam_network_gw_ip = models.CharField(max_length=32, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Gateway IP", help_text="Defaults to first IP address, Eg: 192.168.100.1")
    oam_network_start_ip = models.CharField(max_length=64, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Start IP Address", help_text="Defaults to second IP address, Eg: 192.168.100.2, Total 15 IPs will be consumed starting from this IP")
    oam_network_vlan_id = models.PositiveSmallIntegerField(default=563, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Vlan Id")
    oam_network_bridge = models.CharField(max_length=32, default="oam-bridge", blank=True, null=False, unique=False, verbose_name="Bridge")
    oam_network_bridge_nad = models.CharField(max_length=32, default="oam-bridge-nad", blank=True, null=False, unique=False, verbose_name="Bridge NAD")
    oam_network_rtable_id = models.PositiveSmallIntegerField(default=500, validators=[MinValueValidator(1), MaxValueValidator(5000)], blank=True, null=False, unique=False, verbose_name="Route Table Id")

    sig_network_cidr = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.1.1.0/24", blank=False, null=False, unique=False, verbose_name="CIDR", help_text="Miminum subnet mask /26")
    sig_network_gw_ip = models.CharField(max_length=32, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Gateway IP", help_text="Defaults to first IP address, Eg: 10.1.1.1")
    sig_network_start_ip = models.CharField(max_length=64, validators=[validate_ipv4_custom], blank=True, null=False, unique=False, verbose_name="Start IP Address", help_text="Defaults to second IP address, Eg: 10.1.1.2, Total 35 IPs will be consumed starting from this IP")
    sig_network_vlanid = models.PositiveSmallIntegerField(default=560, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Vlan Id")
    sig_network_bridge = models.CharField(max_length=32, default="sig-bridge", blank=True, null=False, unique=False, verbose_name="Bridge")
    sig_network_bridge_nad = models.CharField(max_length=32, default="sig-bridge-nad", blank=True, null=False, unique=False, verbose_name="Bridge NAD")

    snmp_v3_user = models.CharField(max_length=64, blank=False, null=False, default='privUserApp', verbose_name="User")
    snmp_v3_auth_password = models.CharField(max_length=64, blank=False, null=False, default='authUser', verbose_name="Auth Password")
    snmp_v3_auth_protocol = models.CharField(max_length=32, blank=True, null=False, choices=SNMP_V3_AUTH_PROTO, default='md5', verbose_name="Auth Protocol")
    snmp_v3_privacy_protocol = models.CharField(max_length=32, blank=True, null=False, choices=SNMP_V3_PRIVACY_PROTO, default='des', verbose_name="Privacy Protocol")


    cmg_name = models.CharField(max_length=64, default="UPF01", blank=True, null=False, unique=False, verbose_name="Name")
    cmg_namespace = models.CharField(max_length=64, default="cmu-cmg", blank=True, null=False, unique=False, verbose_name="Namespace")
    cmg_uuid = models.UUIDField(default=uuid.uuid4, blank=True, null=False, unique=False, verbose_name="UUID")
    cmg_autonomous_system_number = models.PositiveIntegerField(default=65001, validators=[MinValueValidator(64512), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Autonomous System Number")
    cmg_base_nodeport_range = models.PositiveIntegerField(default=31000, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Base Node Port Range", help_text="6 ports will be consumed from base range")
    cmg_ssh_port = models.PositiveIntegerField(default=22, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="SSH Port")

    cmg_sys_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="192.168.250.1/32", blank=False, null=False, unique=False, verbose_name="System Loopback IP with Netmask", help_text="IP address with /32 mask")
    cmg_sys_loopback_vlanid = models.PositiveSmallIntegerField(default=564, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="System Loopback(DSF-1) Vlan Id")
    cmg_sig_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.20.0.1/32", blank=False, null=False, unique=False, verbose_name="SIG Loopback IP with Netmask", help_text="IP address with /32 mask")
    cmg_sig_loopback_vlanid = models.PositiveSmallIntegerField(default=565, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="SIG Loopback(DSF-2) Vlan Id")
    cmg_sig_loopback_mac_address = models.CharField(max_length=32, default="fe:ff:10:01:01:02", blank=True, null=False, unique=False, verbose_name="SIG Loopback MAC Address")

    cmg_lb_port1_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.0.1/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-1 IP with Netmask", help_text="IP address with /30 mask")
    cmg_lb_port1_vlanid = models.PositiveSmallIntegerField(default=561, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Loadbalancer Port-1 Vlan Id")
    cmg_lb_port2_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.1.1/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-2 IP with Netmask", help_text="IP address with /30 mask")
    cmg_lb_port2_vlanid = models.PositiveSmallIntegerField(default=562, validators=[MinValueValidator(1), MaxValueValidator(4096)], unique=False, verbose_name="Loadbalancer Port-2 Vlan Id")

    cmg_sriov_enable_dpdk_vlan = models.BooleanField(default=False, verbose_name="SRIOV Enable DPDK Vlan")
    cmg_sriov_vf_pool_namespace = models.CharField(max_length=32, default="openshift.io", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool Namespace")
    cmg_sriov_vf_pool1_name = models.CharField(max_length=32, default="mlxnics1", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-1 Name")
    cmg_sriov_vf_pool1_trust = models.BooleanField(default=True, verbose_name="SRIOV VF Pool-1 Trust ON")
    cmg_sriov_vf_pool2_name = models.CharField(max_length=32, default="mlxnics2", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-2 Name")
    cmg_sriov_vf_pool2_trust = models.BooleanField(default=False, verbose_name="SRIOV VF Pool-2 Trust ON")
    cmg_apn_ip_pool = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.100.0.0/16", blank=True, null=False, unique=False, verbose_name="APN IP Pool")

    sec_cmg_name = models.CharField(max_length=64, default="SMF01", blank=True, null=False, unique=False, verbose_name="Name")
    sec_cmg_namespace = models.CharField(max_length=64, default="cmu-smf", blank=True, null=False, unique=False, verbose_name="Namespace")
    sec_cmg_uuid = models.UUIDField(default=uuid.uuid4, blank=True, null=False, unique=False, verbose_name="UUID")
    sec_cmg_base_nodeport_range = models.PositiveIntegerField(default=32000, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Base Node Port Range", help_text="6 ports will be consumed from base range")
    sec_cmg_ssh_port = models.PositiveIntegerField(default=22, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="SSH Port")

    sec_cmg_sys_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="192.168.250.2/32", blank=False, null=False, unique=False, verbose_name="System Loopback IP with Netmask", help_text="IP address with /32 mask")
    sec_cmg_sys_loopback_vlanid = models.PositiveSmallIntegerField(default=566, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="System Loopback(DSF-1) Vlan Id")
    sec_cmg_sig_loopback_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="10.20.0.2/32", blank=False, null=False, unique=False, verbose_name="SIG Loopback IP with Netmask", help_text="IP address with /32 mask")
    sec_cmg_sig_loopback_vlanid = models.PositiveSmallIntegerField(default=567, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="SIG Loopback(DSF-2) Vlan Id")

    sec_cmg_lb_port1_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.0.2/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-1 IP with Netmask", help_text="IP address with /30 mask")
    sec_cmg_lb_port1_vlanid = models.PositiveSmallIntegerField(default=561, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-1 Vlan Id")
    sec_cmg_lb_port2_ip_with_netmask = models.CharField(max_length=32, validators=[validate_ipv4_custom], default="172.31.1.2/30", blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-2 IP with Netmask", help_text="IP address with /30 mask")
    sec_cmg_lb_port2_vlanid = models.PositiveSmallIntegerField(default=562, validators=[MinValueValidator(1), MaxValueValidator(4096)], blank=False, null=False, unique=False, verbose_name="Loadbalancer Port-2 Vlan Id")

    sec_cmg_sriov_vf_pool_namespace = models.CharField(max_length=32, default="openshift.io", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool Namespace")
    sec_cmg_sriov_vf_pool1_name = models.CharField(max_length=32, default="mlxnics1", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-1 Name")
    sec_cmg_sriov_vf_pool1_trust = models.BooleanField(default=True, verbose_name="SRIOV VF Pool-1 Trust ON")
    sec_cmg_sriov_vf_pool2_name = models.CharField(max_length=32, default="mlxnics2", blank=True, null=False, unique=False, verbose_name="SRIOV VF Pool-2 Name")
    sec_cmg_sriov_vf_pool2_trust = models.BooleanField(default=False, verbose_name="SRIOV VF Pool-2 Trust ON")

    cmm_name = models.CharField(max_length=32, default="AMF01", blank=True, null=False, unique=False, verbose_name="Name")
    cmm_namespace = models.CharField(max_length=32, default="cmu-cmm", blank=True, null=False, unique=False, verbose_name="Namespace")
    cmm_uuid = models.UUIDField(default=uuid.uuid4, blank=True, null=False, unique=False, verbose_name="UUID")

    apc_name = models.CharField(max_length=32, default="APC", blank=True, null=False, unique=False, verbose_name="Name")
    apc_namespace = models.CharField(max_length=32, default="cmu-apc", blank=True, null=False, unique=False, verbose_name="Namespace")
    apc_spr_sync_enable = models.BooleanField(default=False, verbose_name="Enable SPR Synchronization")
    apc_spr_sync_remote_sap_sig_ip = models.CharField(max_length=32, validators=[validate_ipv4_custom], blank=False, null=False, unique=False, verbose_name="SPR Remote SAP SIG IP", help_text="Eg: 192.0.2.3")

    class Meta:
        ordering = ['name']
        verbose_name = 'CMU'
        verbose_name_plural = 'CMUs'
        unique_together = { ('name', 'system_tenant_id'), ('cmu_cluster', 'gui_service_account_name', 'system_tenant_id'), ('cmu_cluster', 'system_namespace', 'system_tenant_id'), ('cmu_cluster', 'gui_namespace', 'system_tenant_id'), ('cmu_cluster', 'system_service_account_name', 'system_tenant_id')}

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:nokia_siteplanner:cmu', args=[self.pk])

    def validate_data(self):
        if self.name == '':
            raise ValidationError('Name must be provided for a CMU')

    def clean(self):
        if self.system_namespace != self.gui_namespace:
            raise ValidationError('System Operator namespace should be same as GUI namespace')
        if self.snmp_v3_auth_password == "":
            raise ValidationError('Enter SNMP Auth Password')
