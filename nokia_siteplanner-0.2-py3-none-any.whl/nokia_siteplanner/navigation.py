from extras.plugins import PluginMenu, PluginMenuButton, PluginMenuGroup, PluginMenuItem, ButtonColorChoices

menu_extensions = [
    PluginMenu(
        label='RAN',
        icon_class='mdi mdi-wan',
        groups=[
            PluginMenuGroup(
                label='NOKIA',
                items=[
                    PluginMenuItem(
                        link='plugins:nokia_siteplanner:gnodeb_list',
                        link_text='GNODEB',
                        permissions=['nokia_siteplanner.view_gnodeb'],
                        buttons=(
                            PluginMenuButton(
                                link='plugins:nokia_siteplanner:gnodeb_add',
                                title='Add',
                                icon_class='mdi mdi-plus-thick',
                                permissions=[
                                    'nokia_siteplanner.add_gnodeb'],
                                color=ButtonColorChoices.GREEN
                            ),
                            PluginMenuButton(
                                link='plugins:nokia_siteplanner:gnodeb_import',
                                title='Import',
                                icon_class='mdi mdi-upload',
                                permissions=[
                                    'nokia_siteplanner.add_gnodeb'],
                                color=ButtonColorChoices.CYAN
                            )
                        )
                    ),
                    PluginMenuItem(
                        link='plugins:nokia_siteplanner:cmu_list',
                        link_text='CMU',
                        permissions=['nokia_siteplanner.view_cmu'],
                        buttons=(
                            PluginMenuButton(
                                link='plugins:nokia_siteplanner:cmu_add',
                                title='Add',
                                icon_class='mdi mdi-plus-thick',
                                permissions=[
                                    'nokia_siteplanner.add_cmu'],
                                color=ButtonColorChoices.GREEN
                            ),
                            PluginMenuButton(
                                link='plugins:nokia_siteplanner:cmu_import',
                                title='Import',
                                icon_class='mdi mdi-upload',
                                permissions=[
                                    'nokia_siteplanner.add_cmu'],
                                color=ButtonColorChoices.CYAN
                            )
                        )
                    ),
                    PluginMenuItem(
                        link='plugins:nokia_siteplanner:cmuprofile_list',
                        link_text='CMUProfile',
                        permissions=['nokia_siteplanner.view_cmuprofile'],
                        buttons=(
                            PluginMenuButton(
                                link='plugins:nokia_siteplanner:cmuprofile_add',
                                title='Add',
                                icon_class='mdi mdi-plus-thick',
                                permissions=[
                                    'nokia_siteplanner.add_cmuprofile'],
                                color=ButtonColorChoices.GREEN
                            ),
                            PluginMenuButton(
                                link='plugins:nokia_siteplanner:cmuprofile_import',
                                title='Import',
                                icon_class='mdi mdi-upload',
                                permissions=[
                                    'nokia_siteplanner.add_cmuprofile'],
                                color=ButtonColorChoices.CYAN
                            )
                        )
                    )
                ]
            )        
        ]
    )
]
