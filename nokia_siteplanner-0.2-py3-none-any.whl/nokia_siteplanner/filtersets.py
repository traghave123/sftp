import django_filters
from django.db.models import Q
from netbox.filtersets import NetBoxModelFilterSet
from .models import CMU, CMUProfile, Gnodeb, CU, DU

__all__ = (
    'GnodebFilterSet',
    'CUFilterSet',
    'DUFilterSet',
    'CMUFilterSet',
    'CMUProfileFilterSet'
)

#GnodeB

class GnodebFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    class Meta:
        model = Gnodeb
        fields = [
            'id',
            'name',
            'description',
            'netact_instance_name'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) | 
            Q(description__icontains=value)
        )  
        
# CU

class CUFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    class Meta:
        model = CU
        fields = [
            'name',
            'namespace',
            'cluster',
            'container_imageregistry',
            'configuration_software_id',
            'nerel_id',
            'vcu_profile_name'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value)
        )
        
# DU

class DUFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    class Meta:
        model = DU
        fields = [
            'name',
            'namespace',
            'cluster',
            'container_imageregistry',
            'configuration_software_id',
            'nerel_id',
            'vdu_profile_name',
            'nop_name',  
            'nop_namespace', 
            'nop_container_imageregistry', 
            'nop_configuration_software_id', 
            'nop_vdu_profile_name', 
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value)
        )
        
# CMU 
class CMUFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search'
    )
    
    class Meta:
        model = CMU
        fields = [
            'id',
            'name',
            'description',
            'cmu_cluster'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) | 
            Q(description__icontains=value)
        )


# CMU Profile
class CMUProfileFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search'
    )
    
    class Meta:
        model = CMUProfile
        fields = [
            'id',
            'name',
            'description'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) |
            Q(description__icontains=value)
        )        

