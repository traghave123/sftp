from utilities.testing import TestCase, APITestCase, APIViewTestCases, ViewTestCases, ModelViewTestCase
from django.forms.models import model_to_dict
from django.contrib.postgres.fields import ArrayField
from django.urls import reverse
from nfvi_common.models.yaml_field import YAMLField
from itertools import chain

class PluginTestCase(TestCase):

    def model_to_dict(self, instance, fields, api=False):
        """
        Override to stop conversion of Tags to comma separated string
        Also to convert YAMLField to a Dict
        """
        model_dict = super().model_to_dict(instance, fields, api=api)

        if api:
            if 'tags' in model_dict and isinstance(model_dict['tags'], str):
                model_dict['tags'] = model_dict['tags'].split(',') if model_dict['tags'] is not None else []
            
            opts = instance._meta
            for f in chain(opts.concrete_fields, opts.private_fields, opts.many_to_many):
                if isinstance(f, YAMLField):
                    # During "model_to_dict" YAMLField will return str, we need a dict (but also need to keep YAMLField's behaviour as is, for other things like forms)
                    if f.name in model_dict:
                        model_dict[f.name] = f.to_python(model_dict[f.name])

        return model_dict

class PluginAPITestCase(PluginTestCase, APITestCase):
    def _get_detail_url(self, instance):
        """
        Override to add "plugins-api"
        """
        viewname = f'plugins-api:{instance._meta.app_label}-api:{instance._meta.model_name}-detail'
        return reverse(viewname, kwargs={'pk': instance.pk})

    def _get_list_url(self):
        """
        Override to add "plugins-api"
        """
        viewname = f'plugins-api:{self.model._meta.app_label}-api:{self.model._meta.model_name}-list'
        return reverse(viewname)


class PluginAPIViewTestCases:

    class GetObjectViewTestCase(PluginAPITestCase, APIViewTestCases.GetObjectViewTestCase):
        pass
    
    class ListObjectsViewTestCase(PluginAPITestCase, APIViewTestCases.ListObjectsViewTestCase):
        pass

    class CreateObjectViewTestCase(PluginAPITestCase, APIViewTestCases.CreateObjectViewTestCase):
        pass

    class UpdateObjectViewTestCase(PluginAPITestCase, APIViewTestCases.UpdateObjectViewTestCase):
        pass

    class DeleteObjectViewTestCase(PluginAPITestCase, APIViewTestCases.DeleteObjectViewTestCase):
        pass

    class GraphQLTestCase(PluginAPITestCase, APIViewTestCases.GraphQLTestCase):
        pass
    
    class RESTAPIViewTestCase(
        GetObjectViewTestCase,
        ListObjectsViewTestCase,
        CreateObjectViewTestCase,
        UpdateObjectViewTestCase,
        DeleteObjectViewTestCase
    ):
        pass

    class APIViewTestCase(
        RESTAPIViewTestCase,
        GraphQLTestCase
    ):
        pass

class PluginModelViewTestCase(PluginTestCase, ModelViewTestCase):

    def _get_base_url(self):
        return 'plugins:{}:{}_{{}}'.format(
            self.model._meta.app_label,
            self.model._meta.model_name
        )

class PluginViewTestCases:

    class GetObjectViewTestCase(PluginModelViewTestCase, ViewTestCases.GetObjectViewTestCase):
        pass

    class GetObjectChangelogViewTestCase(PluginModelViewTestCase, ViewTestCases.GetObjectChangelogViewTestCase):
        pass

    class CreateObjectViewTestCase(PluginModelViewTestCase, ViewTestCases.CreateObjectViewTestCase):
        pass

    class EditObjectViewTestCase(PluginModelViewTestCase, ViewTestCases.EditObjectViewTestCase):
        pass

    class DeleteObjectViewTestCase(PluginModelViewTestCase, ViewTestCases.DeleteObjectViewTestCase):
        pass

    class ListObjectsViewTestCase(PluginModelViewTestCase, ViewTestCases.ListObjectsViewTestCase):
        pass

    class BulkEditObjectsViewTestCase(PluginModelViewTestCase, ViewTestCases.BulkEditObjectsViewTestCase):
        pass

    class BulkImportObjectsViewTestCase(PluginModelViewTestCase, ViewTestCases.BulkImportObjectsViewTestCase):
        pass

    class BulkDeleteObjectsViewTestCase(PluginModelViewTestCase, ViewTestCases.BulkDeleteObjectsViewTestCase):
        pass
    
    class PrimaryObjectViewTestCase(
        GetObjectViewTestCase,
        GetObjectChangelogViewTestCase,
        CreateObjectViewTestCase,
        EditObjectViewTestCase,
        DeleteObjectViewTestCase,
        ListObjectsViewTestCase,
        BulkImportObjectsViewTestCase,
        BulkEditObjectsViewTestCase,
        BulkDeleteObjectsViewTestCase,
    ):
        """
        TestCase suitable for testing all standard View functions for primary objects
        """
        maxDiff = None