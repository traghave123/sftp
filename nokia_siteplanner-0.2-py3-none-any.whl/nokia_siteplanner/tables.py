import django_tables2 as tables
from netbox.tables import NetBoxTable, columns
from .models import CMU, CMUProfile, Gnodeb, CU, DU

__all__ = (
    'GnodebTable',
    'CUTable',
    'DUTable',
    'CMUProfileTable',
    'CMUTable'
)

class GnodebTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:nokia_siteplanner:gnodeb_list'
    )    

    class Meta(NetBoxTable.Meta):
        model = Gnodeb
        fields = (
            'pk', 'name', 'description', 'virtual_infrastructure' , 'netact_instance_name', 'tags', 'gnodebs', 'cugnodebs', 'dugnodebs'
        )
        default_columns = ('pk', 'name', 'description')
        
### CU

class CUTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:nokia_siteplanner:cu_list'
    )    

    class Meta(NetBoxTable.Meta):
        model = CU
        fields = (
            'pk', 'name', 'description', 'namespace', 'cluster', 'configuration_software_id', 'release_name','container_imageregistry', 'nerel_id', 
            'secrets', 'vcu_profile_name','chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version'
        )
        default_columns = ('pk', 'name', 'description')     
        
### DU

class DUTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:nokia_siteplanner:du_list'
    )    

    class Meta(NetBoxTable.Meta):
        model = DU
        fields = (
            'pk', 'name', 'description', 'namespace', 'cluster', 'configuration_software_id', 'release_name','cmu_imageregistry', 'nerel_id', 
            'secrets', 'vdu_profile_name','chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version',
            'nop_name', 'nop_description', 'nop_namespace', 'nop_container_imageregistry', 'nop_configuration_software_id', 'nop_release_name',
            'nop_secrets','nop_vdu_profile_name', 'nop_chart_version'
        )
        default_columns = ('pk', 'name', 'description')     

        
class CMUTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:nokia_siteplanner:cmu_list'
    )    

    class Meta(NetBoxTable.Meta):
        model = CMU
        fields = (
            'pk', 'name', 'description', 'cmu_cluster', 'cmu_profile', 'cmu_deployment_mode', 'cmu_varient', 'cmu_timezone', 'cmu_imageregistry', 'cmu_image_repository', 'cmu_imageregistry_pullsecret', 'cmu_qcow_http_server', 'cmu_qcow_relative_path', 'cmu_bastion_server', 'cmu_ext_ntp_ip_1', 'cmu_ext_ntp_ip_2', 'cmu_ext_nameserver_ip_list', 'cmu_nsp_management_ip', 'system_namespace', 'system_service_account_name', 'system_service_type', 'system_storage_class_name', 'system_image_name', 'system_image_tag', 'gui_replica_count', 'gui_namespace', 'gui_storage_class_name', 'gui_service_account_name', 'gui_cassandra_image_name', 'gui_cassandra_image_tag', 'gui_cassandra_pod_cpu', 'gui_cassandra_pod_memory', 'gui_cassandra_pvc_size', 'gui_cmupfm_image_name', 'gui_cmupfm_image_tag', 'gui_cmupfm_pod_cpu', 'gui_cmupfm_pod_memory', 'gui_consoles_image_name', 'gui_consoles_image_tag', 'gui_gui_image_name', 'gui_gui_image_tag', 'gui_gui_pvc_size', 'gui_service_type', 'gui_https_node_port', 'gui_https_node_port_cmg', 'gui_https_node_port_cmm', 'gui_https_node_port_cmgsec', 'oam_network_name', 'oam_network_cidr', 'oam_network_gw_ip', 'oam_network_start_ip', 'oam_network_vlan_id', 'oam_network_bridge', 'oam_network_bridge_nad', 'oam_network_rtable_id', 'sig_network_cidr', 'sig_network_gw_ip', 'sig_network_start_ip', 'sig_network_vlanid', 'sig_network_bridge', 'sig_network_bridge_nad', 'snmp_v3_user', 'snmp_v3_auth_password', 'snmp_v3_auth_protocol', 'snmp_v3_privacy_protocol', 'cmg_name', 'cmg_namespace', 'cmg_uuid', 'cmg_autonomous_system_number', 'cmg_base_nodeport_range', 'cmg_ssh_port', 'cmg_sys_loopback_ip_with_netmask', 'cmg_sig_loopback_ip_with_netmask', 'cmg_sig_loopback_mac_address', 'cmg_lb_port1_ip_with_netmask', 'cmg_lb_port1_vlanid', 'cmg_lb_port2_ip_with_netmask', 'cmg_lb_port2_vlanid', 'cmg_sys_loopback_vlanid', 'cmg_sig_loopback_vlanid', 'cmg_sriov_enable_dpdk_vlan', 'cmg_sriov_vf_pool_namespace', 'cmg_sriov_vf_pool1_name', 'cmg_sriov_vf_pool1_trust', 'cmg_sriov_vf_pool2_name', 'cmg_sriov_vf_pool2_trust', 'cmg_apn_ip_pool', 'sec_cmg_name', 'sec_cmg_namespace', 'sec_cmg_uuid', 'sec_cmg_base_nodeport_range', 'sec_cmg_ssh_port', 'sec_cmg_sys_loopback_ip_with_netmask', 'sec_cmg_sig_loopback_ip_with_netmask', 'sec_cmg_lb_port1_ip_with_netmask', 'sec_cmg_lb_port1_vlanid', 'sec_cmg_lb_port2_ip_with_netmask', 'sec_cmg_lb_port2_vlanid', 'sec_cmg_sys_loopback_vlanid', 'sec_cmg_sig_loopback_vlanid', 'sec_cmg_sriov_vf_pool_namespace', 'sec_cmg_sriov_vf_pool1_name', 'sec_cmg_sriov_vf_pool1_trust', 'sec_cmg_sriov_vf_pool2_name', 'sec_cmg_sriov_vf_pool2_trust', 'cmm_name', 'cmm_namespace', 'cmm_uuid', 'apc_name', 'apc_namespace', 'apc_spr_sync_enable', 'apc_spr_sync_remote_sap_sig_ip', 'tags'
        )
        default_columns = ('pk', 'name', 'description')

        
class CMUProfileTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:nokia_siteplanner:cmuprofile_list'
    )    

    class Meta(NetBoxTable.Meta):
        model = CMUProfile
        fields = (
            'pk', 'name', 'description', 'cmu_deployment_mode', 'cmu_varient', 'cmu_timezone', 'cmu_imageregistry', 'cmu_image_repository', 'cmu_imageregistry_pullsecret', 'cmu_qcow_http_server', 'cmu_qcow_relative_path', 'cmu_bastion_server', 'cmu_ext_ntp_ip_1', 'cmu_ext_ntp_ip_2', 'cmu_ext_nameserver_ip_list', 'cmu_nsp_management_ip', 'system_namespace', 'system_service_account_name', 'system_service_type', 'system_storage_class_name', 'system_image_name', 'system_image_tag', 'gui_replica_count', 'gui_namespace', 'gui_storage_class_name', 'gui_service_account_name', 'gui_cassandra_image_name', 'gui_cassandra_image_tag', 'gui_cassandra_pod_cpu', 'gui_cassandra_pod_memory', 'gui_cassandra_pvc_size', 'gui_cmupfm_image_name', 'gui_cmupfm_image_tag', 'gui_cmupfm_pod_cpu', 'gui_cmupfm_pod_memory', 'gui_consoles_image_name', 'gui_consoles_image_tag', 'gui_gui_image_name', 'gui_gui_image_tag', 'gui_gui_pvc_size', 'gui_service_type', 'gui_https_node_port', 'gui_https_node_port_cmg', 'gui_https_node_port_cmm', 'gui_https_node_port_cmgsec', 'oam_network_name', 'oam_network_cidr', 'oam_network_gw_ip', 'oam_network_start_ip', 'oam_network_vlan_id', 'oam_network_bridge', 'oam_network_bridge_nad', 'oam_network_rtable_id', 'sig_network_cidr', 'sig_network_gw_ip', 'sig_network_start_ip', 'sig_network_vlanid', 'sig_network_bridge', 'sig_network_bridge_nad', 'snmp_v3_user', 'snmp_v3_auth_password', 'snmp_v3_auth_protocol', 'snmp_v3_privacy_protocol', 'cmg_name', 'cmg_namespace', 'cmg_uuid', 'cmg_autonomous_system_number', 'cmg_base_nodeport_range', 'cmg_ssh_port', 'cmg_sys_loopback_ip_with_netmask', 'cmg_sig_loopback_ip_with_netmask', 'cmg_sig_loopback_mac_address', 'cmg_lb_port1_ip_with_netmask', 'cmg_lb_port1_vlanid', 'cmg_lb_port2_ip_with_netmask', 'cmg_lb_port2_vlanid', 'cmg_sys_loopback_vlanid', 'cmg_sig_loopback_vlanid', 'cmg_sriov_enable_dpdk_vlan','cmg_sriov_vf_pool_namespace', 'cmg_sriov_vf_pool1_name', 'cmg_sriov_vf_pool1_trust', 'cmg_sriov_vf_pool2_name', 'cmg_sriov_vf_pool2_trust', 'cmg_apn_ip_pool', 'sec_cmg_name', 'sec_cmg_namespace', 'sec_cmg_uuid', 'sec_cmg_base_nodeport_range', 'sec_cmg_ssh_port', 'sec_cmg_sys_loopback_ip_with_netmask', 'sec_cmg_sig_loopback_ip_with_netmask', 'sec_cmg_lb_port1_ip_with_netmask', 'sec_cmg_lb_port1_vlanid', 'sec_cmg_lb_port2_ip_with_netmask', 'sec_cmg_lb_port2_vlanid', 'sec_cmg_sys_loopback_vlanid', 'sec_cmg_sig_loopback_vlanid', 'sec_cmg_sriov_vf_pool_namespace', 'sec_cmg_sriov_vf_pool1_name', 'sec_cmg_sriov_vf_pool1_trust', 'sec_cmg_sriov_vf_pool2_name', 'sec_cmg_sriov_vf_pool2_trust', 'cmm_name', 'cmm_namespace', 'cmm_uuid', 'apc_name', 'apc_namespace', 'apc_spr_sync_enable', 'apc_spr_sync_remote_sap_sig_ip', 'tags'
        )
        default_columns = ('pk', 'name', 'description')
