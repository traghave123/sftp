from extras.plugins import PluginSearchType, PluginSearchGroup, PlacedPluginSearchType
from .filtersets import CMUFilterSet, CMUProfileFilterSet, GnodebFilterSet, CUFilterSet, DUFilterSet
from .models import CMU, CMUProfile, Gnodeb, CU, DU
from .tables import CMUTable, CMUProfileTable, GnodebTable, CUTable, DUTable


search_groups = [
    PluginSearchGroup(
        label='NOKIA',
        types={
            'cmus': PluginSearchType(
                label='CMU',
                queryset=CMU.objects.all(),
                filterset=CMUFilterSet,
                url='plugins:nokia_siteplanner:cmu_list',
                table=CMUTable
            ),
            'cmuprofiles': PluginSearchType(
                label='CMUProfile',
                queryset=CMUProfile.objects.all(),
                filterset=CMUProfileFilterSet,
                url='plugins:nokia_siteplanner:cmuprofile_list',
                table=CMUProfileTable
            ),
            'gnodebs': PluginSearchType(
                label='GNODEB',
                queryset=Gnodeb.objects.all(),
                filterset=GnodebFilterSet,
                url='plugins:nokia_siteplanner:gnodeb_list',
                table=GnodebTable
            ),
            'cus': PluginSearchType(
                label='CU',
                queryset=CU.objects.all(),
                filterset=CUFilterSet,
                url='plugins:nokia_siteplanner:cu_list',
                table=CUTable
            ), 
            'dus': PluginSearchType(
                label='DU',
                queryset=DU.objects.all(),
                filterset=DUFilterSet,
                url='plugins:nokia_siteplanner:du_list',
                table=DUTable
            )              
        }
    )
]

search_types = {
    'cmu': PlacedPluginSearchType(
        parent_label='NOKIA',
        label='CMU',
        queryset=CMU.objects.all(),
        filterset=CMUFilterSet,
        url='plugins:nokia_siteplanner:cmu_list',
        table=CMUTable
    ),
    'cmuprofile': PlacedPluginSearchType(
        parent_label='NOKIA',
        label='CMUProfile',
        queryset=CMUProfile.objects.all(),
        filterset=CMUProfileFilterSet,
        url='plugins:nokia_siteplanner:cmuprofile_list',
        table=CMUProfileTable
    ),
    'gnodeb': PlacedPluginSearchType(
        parent_label='NOKIA',
        label='Gnodeb',
        queryset=Gnodeb.objects.all(),
        filterset=GnodebFilterSet,
        url='plugins:nokia_siteplanner:gnode_list',
        table=GnodebTable
    ),
    'cu': PlacedPluginSearchType(
        parent_label='NOKIA',
        label='CU',
        queryset=CU.objects.all(),
        filterset=CUFilterSet,
        url='plugins:nokia_siteplanner:cu_list',
        table=CUTable
    ),
    'du': PlacedPluginSearchType(
        parent_label='NOKIA',
        label='DU',
        queryset=DU.objects.all(),
        filterset=DUFilterSet,
        url='plugins:nokia_siteplanner:du_list',
        table=DUTable
    )      
}
