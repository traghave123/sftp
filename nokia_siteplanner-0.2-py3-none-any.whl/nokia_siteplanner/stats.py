from extras.plugins import PluginDashboardStatSection, PluginDashboardStatItem, PlacedPluginDashboardStatItem
from .models import CMU, CMUProfile, Gnodeb, CU, DU


stat_extensions = [
    PluginDashboardStatSection(
        label='NOKIA',
        icon_class_suffix='layers-triple',
        items=[
            PluginDashboardStatItem(
                label='CMU',
                perm='nokia_siteplanner.view_cmu',
                count_queryset=CMU.objects
            ),
            PluginDashboardStatItem(
                label='CMUProfile',
                perm='nokia_siteplanner.view_cmuprofile',
                count_queryset=CMUProfile.objects
            ),
            PluginDashboardStatItem(
                label='GNODEB',
                perm='nokia_siteplanner.view_gnodeb',
                count_queryset=Gnodeb.objects
            ),            
        ]
    )
]
