from nfvi_automation.models.object_type_metadata import ObjectTypeAutomationMetadata
from .models import CMU ,Gnodeb, CU, DU


class CMUAutomationMetadata(ObjectTypeAutomationMetadata):
    name = 'nokia_siteplanner.cmu'
    display_name = 'CMU'
    model = CMU
    automation_url_group = 'plugins:nokia_siteplanner'
    automation_url_prefix = 'cmus'
    graphql_arg_fields = ['id', 'cmu_cluster__id', 'cmu_imageregistry__id', 'cmu_qcow_http_server__id', 'cmu_bastion_server__id' ]
cmu_metadata = CMUAutomationMetadata()


class GnodebAutomationMetadata(ObjectTypeAutomationMetadata):
    name = 'nokia_siteplanner.gnodeb'
    display_name = 'Gnodeb'
    model = Gnodeb
    automation_url_group = 'plugins:nokia_siteplanner'
    automation_url_prefix = 'gnodebs'
    graphql_arg_fields = ['id', 'name', 'tags', 'virtual_infrastructure__id', 'virtual_infrastructure__name']

gnodeb_metadata = GnodebAutomationMetadata()


class CUAutomationMetadata(ObjectTypeAutomationMetadata):
    name = 'nokia_siteplanner.cu'
    display_name = 'CU'
    model = CU
    automation_url_group = 'plugins:nokia_siteplanner'
    automation_url_prefix = 'cu'
    graphql_arg_fields = ['id', 'name', 'description', 'namespace', 'cluster','container_imageregistry', 'configuration_software_id', 'release_name', 'nerel_id',
                          'secrets','vcu_profile_name', 'chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version']

cu_metadata = CUAutomationMetadata()

class DUAutomationMetadata(ObjectTypeAutomationMetadata):
    name = 'nokia_siteplanner.dudevice'
    display_name = 'DU'
    model = DU
    automation_url_group = 'plugins:nokia_siteplanner'
    automation_url_prefix = 'dus'
    graphql_arg_fields = ['id', 'name', 'namespace', 'cluster','container_imageregistry', 'configuration_software_id', 'release_name', 'nerel_id', 
                          'secrets', 'vdu_profile_name','chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version',
                          'nop_name', 'nop_description', 'nop_namespace', 'nop_container_imageregistry', 'nop_configuration_software_id', 'nop_release_name',
                          'nop_secrets','nop_vdu_profile_name', 'nop_chart_version']

du_metadata = DUAutomationMetadata()

