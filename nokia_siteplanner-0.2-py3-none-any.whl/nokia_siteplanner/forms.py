from django import forms
from netbox.forms import NetBoxModelForm, NetBoxModelCSVForm, NetBoxModelBulkEditForm, NetBoxModelFilterSetForm
from extras.models import Tag
from utilities.forms import (CommentField, CSVModelChoiceField,
                             DynamicModelChoiceField,
                             DynamicModelMultipleChoiceField, JSONField,
                             NumericArrayField, SmallTextarea, TagFilterField, 
                             StaticSelect, StaticSelectMultiple)
from .models import CMU, CMUProfile, Gnodeb, CU, DU

#
#Gnodeb
#

class GnodebForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )

    class Meta:
        model = Gnodeb
        fields = [
            'name',
            'description',
            'virtual_infrastructure',
            'netact_instance_name',
            'tags'  
        ]
        
class GnodebFilterForm(NetBoxModelFilterSetForm):
    model = Gnodeb
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class GnodebCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = Gnodeb
        fields = [
            'name',
            'description',
            'virtual_infrastructure',
            'netact_instance_name',
            'tags'           
        ]


class GnodebBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    ) 
    model = Gnodeb
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )
        
#
# CU
#

class CUForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )

    class Meta:
        model = CU
        fields = [
            'name',
            'description',
            'namespace',
            'cluster',
            'configuration_software_id',
            'release_name',
            'container_imageregistry',
            'nerel_id',
            'secrets',
            'vcu_profile_name',
            'chart_version',
            'prerequisites_chart_version', 
            'cluster_preparation_chart_version',
            'gnodeb'
        ]
        
class CUFilterForm(NetBoxModelFilterSetForm):
    model = CU
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class CUCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = CU
        fields = [
            'name',
            'description',
            'namespace',
            'cluster',
            'configuration_software_id',
            'release_name',
            'container_imageregistry',
            'nerel_id',
            'vcu_profile_name',
            'chart_version', 
            'prerequisites_chart_version', 
            'cluster_preparation_chart_version',
            'secrets'
        ]


class CUBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    ) 
    model = CU
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )
    
#
# DU
#

class DUForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )
    fieldsets = (
        ('DU', (
        'name',
        'description',
        'namespace',
        'cluster',
        'configuration_software_id',
        'release_name',
        'container_imageregistry',
        'nerel_id',
        'vdu_profile_name',
        'chart_version', 
        'prerequisites_chart_version', 
        'cluster_preparation_chart_version',
        'secrets',
        'gnodeb')),
    ('NOP', (
        'nop_name', 
        'nop_description', 
        'nop_namespace', 
        'nop_container_imageregistry', 
        'nop_configuration_software_id', 
        'nop_release_name',
        'nop_secrets',
        'nop_vdu_profile_name', 
        'nop_chart_version'
        )))

    class Meta:
        model = DU
        fields = [
                'name',
                'description',
                'namespace',
                'cluster',
                'configuration_software_id',
                'release_name',
                'container_imageregistry',
                'nerel_id',
                'vdu_profile_name',
                'chart_version', 
                'prerequisites_chart_version', 
                'cluster_preparation_chart_version',
                'secrets',
                'nop_name', 
                'nop_description', 
                'nop_namespace', 
                'nop_container_imageregistry', 
                'nop_configuration_software_id', 
                'nop_release_name', 
                'nop_secrets',
                'nop_vdu_profile_name', 
                'nop_chart_version',
                'gnodeb']
            
        
class DUFilterForm(NetBoxModelFilterSetForm):
    model = DU
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class DUCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = DU
        fields = [
                'name',
                'description',
                'namespace',
                'cluster',
                'configuration_software_id',
                'release_name',
                'container_imageregistry',
                'nerel_id',
                'vdu_profile_name',
                'chart_version', 
                'prerequisites_chart_version', 
                'cluster_preparation_chart_version',
                'secrets',
                'nop_name', 
                'nop_description', 
                'nop_namespace', 
                'nop_container_imageregistry', 
                'nop_configuration_software_id', 
                'nop_release_name', 
                'nop_secrets',
                'nop_vdu_profile_name', 
                'nop_chart_version']

            
        


class DUBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    ) 
    model = DU
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )

#
# CMU
#

class CMUForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )

    snmp_v3_auth_password = forms.CharField(widget=forms.PasswordInput(), label="Auth Password")

    fieldsets = (
        ('Nokia CMU', (
                    'name',
                    'description',
                    'cmu_cluster',
                    'cmu_profile',
                    'cmu_deployment_mode',
                    'cmu_varient',
                    'cmu_timezone',
                    'cmu_imageregistry',
                    'cmu_image_repository',
                    'cmu_imageregistry_pullsecret',
                    'cmu_qcow_http_server',
                    'cmu_qcow_relative_path',
                    'cmu_bastion_server',
                    'cmu_ext_ntp_ip_1',
                    'cmu_ext_ntp_ip_2',
                    'cmu_ext_nameserver_ip_list',
                    'cmu_nsp_management_ip')),
        ('System Operator', (
                    'system_namespace',
                    'system_service_account_name',
                    'system_service_type',
                    'system_storage_class_name',
                    'system_image_name',
                    'system_image_tag')),
        ('GUI', (
                    'gui_replica_count',
                    'gui_namespace',
                    'gui_storage_class_name',
                    'gui_service_account_name',
                    'gui_cassandra_image_name',
                    'gui_cassandra_image_tag',
                    'gui_cassandra_pod_cpu',
                    'gui_cassandra_pod_memory',
                    'gui_cassandra_pvc_size',
                    'gui_cmupfm_image_name',
                    'gui_cmupfm_image_tag',
                    'gui_cmupfm_pod_cpu',
                    'gui_cmupfm_pod_memory',
                    'gui_consoles_image_name',
                    'gui_consoles_image_tag',
                    'gui_gui_image_name',
                    'gui_gui_image_tag',
                    'gui_gui_pvc_size',
                    'gui_service_type',
                    'gui_https_node_port',
                    'gui_https_node_port_cmg',
                    'gui_https_node_port_cmm',
                    'gui_https_node_port_cmgsec')),
        ('Operations and Management Network', (
                    'oam_network_name',
                    'oam_network_cidr',
                    'oam_network_gw_ip',
                    'oam_network_start_ip',
                    'oam_network_vlan_id',
                    'oam_network_bridge',
                    'oam_network_bridge_nad',
                    'oam_network_rtable_id')),
        ('Signalling Network', (
                    'sig_network_cidr',
                    'sig_network_gw_ip',
                    'sig_network_start_ip',
                    'sig_network_vlanid',
                    'sig_network_bridge',
                    'sig_network_bridge_nad')),
        ('SNMP V3', (
                    'snmp_v3_user',
                    'snmp_v3_auth_password',
                    'snmp_v3_auth_protocol',
                    'snmp_v3_privacy_protocol')),
        ('Cloud Mobile Gateway', (
                    'cmg_name',
                    'cmg_namespace',
                    'cmg_uuid',
                    'cmg_autonomous_system_number',
                    'cmg_base_nodeport_range',
                    'cmg_ssh_port',
                    'cmg_sys_loopback_ip_with_netmask',
                    'cmg_sys_loopback_vlanid',
                    'cmg_sig_loopback_ip_with_netmask',
                    'cmg_sig_loopback_vlanid',
                    'cmg_sig_loopback_mac_address',
                    'cmg_lb_port1_ip_with_netmask',
                    'cmg_lb_port1_vlanid',
                    'cmg_lb_port2_ip_with_netmask',
                    'cmg_lb_port2_vlanid',
                    'cmg_sriov_enable_dpdk_vlan',
                    'cmg_sriov_vf_pool_namespace',
                    'cmg_sriov_vf_pool1_name',
                    'cmg_sriov_vf_pool1_trust',
                    'cmg_sriov_vf_pool2_name',
                    'cmg_sriov_vf_pool2_trust',
                    'cmg_apn_ip_pool')),
        ('Secondary Cloud Mobile Gateway', (
                    'sec_cmg_name',
                    'sec_cmg_namespace',
                    'sec_cmg_uuid',
                    'sec_cmg_base_nodeport_range',
                    'sec_cmg_ssh_port',
                    'sec_cmg_sys_loopback_ip_with_netmask',
                    'sec_cmg_sys_loopback_vlanid',
                    'sec_cmg_sig_loopback_ip_with_netmask',
                    'sec_cmg_sig_loopback_vlanid',
                    'sec_cmg_lb_port1_ip_with_netmask',
                    'sec_cmg_lb_port1_vlanid',
                    'sec_cmg_lb_port2_ip_with_netmask',
                    'sec_cmg_lb_port2_vlanid',
                    'sec_cmg_sriov_vf_pool_namespace',
                    'sec_cmg_sriov_vf_pool1_name',
                    'sec_cmg_sriov_vf_pool1_trust',
                    'sec_cmg_sriov_vf_pool2_name',
                    'sec_cmg_sriov_vf_pool2_trust')),
        ('Cloud Mobility Manager', (
                    'cmm_name',
                    'cmm_namespace',
                    'cmm_uuid')),
        ('Authentication and Policy Control', (
                    'apc_name',
                    'apc_namespace',
                    'apc_spr_sync_enable',
                    'apc_spr_sync_remote_sap_sig_ip'))
    )

    class Meta:
        model = CMU
        fields = [
            'name',
            'description',
            'cmu_cluster',
            'cmu_profile',
            'cmu_deployment_mode',
            'cmu_varient',
            'cmu_timezone',
            'cmu_imageregistry',
            'cmu_image_repository',
            'cmu_imageregistry_pullsecret',
            'cmu_qcow_http_server',
            'cmu_qcow_relative_path',
            'cmu_bastion_server',
            'cmu_ext_ntp_ip_1',
            'cmu_ext_ntp_ip_2',
            'cmu_ext_nameserver_ip_list',
            'cmu_nsp_management_ip',
            'system_namespace',
            'system_service_account_name',
            'system_service_type',
            'system_storage_class_name',
            'system_image_name',
            'system_image_tag',
            'gui_replica_count',
            'gui_namespace',
            'gui_storage_class_name',
            'gui_service_account_name',
            'gui_cassandra_image_name',
            'gui_cassandra_image_tag',
            'gui_cassandra_pod_cpu',
            'gui_cassandra_pod_memory',
            'gui_cassandra_pvc_size',
            'gui_cmupfm_image_name',
            'gui_cmupfm_image_tag',
            'gui_cmupfm_pod_cpu',
            'gui_cmupfm_pod_memory',
            'gui_consoles_image_name',
            'gui_consoles_image_tag',
            'gui_gui_image_name',
            'gui_gui_image_tag',
            'gui_gui_pvc_size',
            'gui_service_type',
            'gui_https_node_port',
            'gui_https_node_port_cmg',
            'gui_https_node_port_cmm',
            'gui_https_node_port_cmgsec',
            'oam_network_name',
            'oam_network_cidr',
            'oam_network_gw_ip',
            'oam_network_start_ip',
            'oam_network_vlan_id',
            'oam_network_bridge',
            'oam_network_bridge_nad',
            'oam_network_rtable_id',
            'sig_network_cidr',
            'sig_network_gw_ip',
            'sig_network_start_ip',
            'sig_network_vlanid',
            'sig_network_bridge',
            'sig_network_bridge_nad',
            'snmp_v3_user',
            'snmp_v3_auth_password',
            'snmp_v3_auth_protocol',
            'snmp_v3_privacy_protocol',
            'cmg_name',
            'cmg_namespace',
            'cmg_uuid',
            'cmg_autonomous_system_number',
            'cmg_base_nodeport_range',
            'cmg_ssh_port',
            'cmg_sys_loopback_ip_with_netmask',
            'cmg_sys_loopback_vlanid',
            'cmg_sig_loopback_ip_with_netmask',
            'cmg_sig_loopback_vlanid',
            'cmg_sig_loopback_mac_address',
            'cmg_lb_port1_ip_with_netmask',
            'cmg_lb_port1_vlanid',
            'cmg_lb_port2_ip_with_netmask',
            'cmg_lb_port2_vlanid',
            'cmg_sriov_enable_dpdk_vlan',
            'cmg_sriov_vf_pool_namespace',
            'cmg_sriov_vf_pool1_name',
            'cmg_sriov_vf_pool1_trust',
            'cmg_sriov_vf_pool2_name',
            'cmg_sriov_vf_pool2_trust',
            'cmg_apn_ip_pool',
            'sec_cmg_name',
            'sec_cmg_namespace',
            'sec_cmg_uuid',
            'sec_cmg_base_nodeport_range',
            'sec_cmg_ssh_port',
            'sec_cmg_sys_loopback_ip_with_netmask',
            'sec_cmg_sys_loopback_vlanid',
            'sec_cmg_sig_loopback_ip_with_netmask',
            'sec_cmg_sig_loopback_vlanid',
            'sec_cmg_lb_port1_ip_with_netmask',
            'sec_cmg_lb_port1_vlanid',
            'sec_cmg_lb_port2_ip_with_netmask',
            'sec_cmg_lb_port2_vlanid',
            'sec_cmg_sriov_vf_pool_namespace',
            'sec_cmg_sriov_vf_pool1_name',
            'sec_cmg_sriov_vf_pool1_trust',
            'sec_cmg_sriov_vf_pool2_name',
            'sec_cmg_sriov_vf_pool2_trust',
            'cmm_name',
            'cmm_namespace',
            'cmm_uuid',
            'apc_name',
            'apc_namespace',
            'apc_spr_sync_enable',
            'apc_spr_sync_remote_sap_sig_ip'
        ]


class CMUFilterForm(NetBoxModelFilterSetForm):
    model = CMU
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class CMUCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = CMU
        fields = [
            'name',
            'description',
            'cmu_cluster',
            'cmu_profile',
            'cmu_deployment_mode',
            'cmu_varient',
            'cmu_timezone',
            'cmu_imageregistry',
            'cmu_image_repository',
            'cmu_imageregistry_pullsecret',
            'cmu_qcow_http_server',
            'cmu_qcow_relative_path',
            'cmu_bastion_server',
            'cmu_ext_ntp_ip_1',
            'cmu_ext_ntp_ip_2',
            'cmu_ext_nameserver_ip_list',
            'cmu_nsp_management_ip',
            'system_namespace',
            'system_service_account_name',
            'system_service_type',
            'system_storage_class_name',
            'system_image_name',
            'system_image_tag',
            'gui_replica_count',
            'gui_namespace',
            'gui_storage_class_name',
            'gui_service_account_name',
            'gui_cassandra_image_name',
            'gui_cassandra_image_tag',
            'gui_cassandra_pod_cpu',
            'gui_cassandra_pod_memory',
            'gui_cassandra_pvc_size',
            'gui_cmupfm_image_name',
            'gui_cmupfm_image_tag',
            'gui_cmupfm_pod_cpu',
            'gui_cmupfm_pod_memory',
            'gui_consoles_image_name',
            'gui_consoles_image_tag',
            'gui_gui_image_name',
            'gui_gui_image_tag',
            'gui_gui_pvc_size',
            'gui_service_type',
            'gui_https_node_port',
            'gui_https_node_port_cmg',
            'gui_https_node_port_cmm',
            'gui_https_node_port_cmgsec',
            'oam_network_name',
            'oam_network_cidr',
            'oam_network_gw_ip',
            'oam_network_start_ip',
            'oam_network_vlan_id',
            'oam_network_bridge',
            'oam_network_bridge_nad',
            'oam_network_rtable_id',
            'sig_network_cidr',
            'sig_network_gw_ip',
            'sig_network_start_ip',
            'sig_network_vlanid',
            'sig_network_bridge',
            'sig_network_bridge_nad',
            'snmp_v3_user',
            'snmp_v3_auth_password',
            'snmp_v3_auth_protocol',
            'snmp_v3_privacy_protocol',
            'cmg_name',
            'cmg_namespace',
            'cmg_uuid',
            'cmg_autonomous_system_number',
            'cmg_base_nodeport_range',
            'cmg_ssh_port',
            'cmg_sys_loopback_ip_with_netmask',
            'cmg_sys_loopback_vlanid',
            'cmg_sig_loopback_ip_with_netmask',
            'cmg_sig_loopback_vlanid',
            'cmg_sig_loopback_mac_address',
            'cmg_lb_port1_ip_with_netmask',
            'cmg_lb_port1_vlanid',
            'cmg_lb_port2_ip_with_netmask',
            'cmg_lb_port2_vlanid',
            'cmg_sriov_enable_dpdk_vlan',
            'cmg_sriov_vf_pool_namespace',
            'cmg_sriov_vf_pool1_name',
            'cmg_sriov_vf_pool1_trust',
            'cmg_sriov_vf_pool2_name',
            'cmg_sriov_vf_pool2_trust',
            'cmg_apn_ip_pool',
            'sec_cmg_name',
            'sec_cmg_namespace',
            'sec_cmg_uuid',
            'sec_cmg_base_nodeport_range',
            'sec_cmg_ssh_port',
            'sec_cmg_sys_loopback_ip_with_netmask',
            'sec_cmg_sys_loopback_vlanid',
            'sec_cmg_sig_loopback_ip_with_netmask',
            'sec_cmg_sig_loopback_vlanid',
            'sec_cmg_lb_port1_ip_with_netmask',
            'sec_cmg_lb_port1_vlanid',
            'sec_cmg_lb_port2_ip_with_netmask',
            'sec_cmg_lb_port2_vlanid',
            'sec_cmg_sriov_vf_pool_namespace',
            'sec_cmg_sriov_vf_pool1_name',
            'sec_cmg_sriov_vf_pool1_trust',
            'sec_cmg_sriov_vf_pool2_name',
            'sec_cmg_sriov_vf_pool2_trust',
            'cmm_name',
            'cmm_namespace',
            'cmm_uuid',
            'apc_name',
            'apc_namespace',
            'apc_spr_sync_enable',
            'apc_spr_sync_remote_sap_sig_ip'
        ]


class CMUBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    ) 
    model = CMU
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )



#
# CMU Profile
#

class CMUProfileForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )

    snmp_v3_auth_password = forms.CharField(widget=forms.PasswordInput(), label="Auth Password")

    fieldsets = (
        ('Nokia CMU', (
                    'name',
                    'description',
                    'cmu_deployment_mode',
                    'cmu_varient',
                    'cmu_timezone',
                    'cmu_imageregistry',
                    'cmu_image_repository',
                    'cmu_imageregistry_pullsecret',
                    'cmu_qcow_http_server',
                    'cmu_qcow_relative_path',
                    'cmu_bastion_server',
                    'cmu_ext_ntp_ip_1',
                    'cmu_ext_ntp_ip_2',
                    'cmu_ext_nameserver_ip_list',
                    'cmu_nsp_management_ip')),
        ('System Operator', (
                    'system_namespace',
                    'system_service_account_name',
                    'system_service_type',
                    'system_storage_class_name',
                    'system_image_name',
                    'system_image_tag')),
        ('GUI', (
                    'gui_replica_count',
                    'gui_namespace',
                    'gui_storage_class_name',
                    'gui_service_account_name',
                    'gui_cassandra_image_name',
                    'gui_cassandra_image_tag',
                    'gui_cassandra_pod_cpu',
                    'gui_cassandra_pod_memory',
                    'gui_cassandra_pvc_size',
                    'gui_cmupfm_image_name',
                    'gui_cmupfm_image_tag',
                    'gui_cmupfm_pod_cpu',
                    'gui_cmupfm_pod_memory',
                    'gui_consoles_image_name',
                    'gui_consoles_image_tag',
                    'gui_gui_image_name',
                    'gui_gui_image_tag',
                    'gui_gui_pvc_size',
                    'gui_service_type',
                    'gui_https_node_port',
                    'gui_https_node_port_cmg',
                    'gui_https_node_port_cmm',
                    'gui_https_node_port_cmgsec')),
        ('Operations and Management Network', (
                    'oam_network_name',
                    'oam_network_cidr',
                    'oam_network_gw_ip',
                    'oam_network_start_ip',
                    'oam_network_vlan_id',
                    'oam_network_bridge',
                    'oam_network_bridge_nad',
                    'oam_network_rtable_id')),
        ('Signalling Network', (
                    'sig_network_cidr',
                    'sig_network_gw_ip',
                    'sig_network_start_ip',
                    'sig_network_vlanid',
                    'sig_network_bridge',
                    'sig_network_bridge_nad')),
        ('SNMP V3', (
                    'snmp_v3_user',
                    'snmp_v3_auth_password',
                    'snmp_v3_auth_protocol',
                    'snmp_v3_privacy_protocol')),
        ('Cloud Mobile Gateway', (
                    'cmg_name',
                    'cmg_namespace',
                    'cmg_uuid',
                    'cmg_autonomous_system_number',
                    'cmg_base_nodeport_range',
                    'cmg_ssh_port',
                    'cmg_sys_loopback_ip_with_netmask',
                    'cmg_sys_loopback_vlanid',
                    'cmg_sig_loopback_ip_with_netmask',
                    'cmg_sig_loopback_vlanid',
                    'cmg_sig_loopback_mac_address',
                    'cmg_lb_port1_ip_with_netmask',
                    'cmg_lb_port1_vlanid',
                    'cmg_lb_port2_ip_with_netmask',
                    'cmg_lb_port2_vlanid',
                    'cmg_sriov_enable_dpdk_vlan',
                    'cmg_sriov_vf_pool_namespace',
                    'cmg_sriov_vf_pool1_name',
                    'cmg_sriov_vf_pool1_trust',
                    'cmg_sriov_vf_pool2_name',
                    'cmg_sriov_vf_pool2_trust',
                    'cmg_apn_ip_pool')),
        ('Secondary Cloud Mobile Gateway', (
                    'sec_cmg_name',
                    'sec_cmg_namespace',
                    'sec_cmg_uuid',
                    'sec_cmg_base_nodeport_range',
                    'sec_cmg_ssh_port',
                    'sec_cmg_sys_loopback_ip_with_netmask',
                    'sec_cmg_sys_loopback_vlanid',
                    'sec_cmg_sig_loopback_ip_with_netmask',
                    'sec_cmg_sig_loopback_vlanid',
                    'sec_cmg_lb_port1_ip_with_netmask',
                    'sec_cmg_lb_port1_vlanid',
                    'sec_cmg_lb_port2_ip_with_netmask',
                    'sec_cmg_lb_port2_vlanid',
                    'sec_cmg_sriov_vf_pool_namespace',
                    'sec_cmg_sriov_vf_pool1_name',
                    'sec_cmg_sriov_vf_pool1_trust',
                    'sec_cmg_sriov_vf_pool2_name',
                    'sec_cmg_sriov_vf_pool2_trust')),
        ('Cloud Mobility Manager', (
                    'cmm_name',
                    'cmm_namespace',
                    'cmm_uuid')),
        ('Authentication and Policy Control', (
                    'apc_name',
                    'apc_namespace',
                    'apc_spr_sync_enable',
                    'apc_spr_sync_remote_sap_sig_ip'))
    )


    class Meta:
        model = CMUProfile
        fields = [
            'name',
            'description',
            'cmu_deployment_mode',
            'cmu_varient',
            'cmu_timezone',
            'cmu_imageregistry',
            'cmu_image_repository',
            'cmu_imageregistry_pullsecret',
            'cmu_qcow_http_server',
            'cmu_qcow_relative_path',
            'cmu_bastion_server',
            'cmu_ext_ntp_ip_1',
            'cmu_ext_ntp_ip_2',
            'cmu_ext_nameserver_ip_list',
            'cmu_nsp_management_ip',
            'system_namespace',
            'system_service_account_name',
            'system_service_type',
            'system_storage_class_name',
            'system_image_name',
            'system_image_tag',
            'gui_replica_count',
            'gui_namespace',
            'gui_storage_class_name',
            'gui_service_account_name',
            'gui_cassandra_image_name',
            'gui_cassandra_image_tag',
            'gui_cassandra_pod_cpu',
            'gui_cassandra_pod_memory',
            'gui_cassandra_pvc_size',
            'gui_cmupfm_image_name',
            'gui_cmupfm_image_tag',
            'gui_cmupfm_pod_cpu',
            'gui_cmupfm_pod_memory',
            'gui_consoles_image_name',
            'gui_consoles_image_tag',
            'gui_gui_image_name',
            'gui_gui_image_tag',
            'gui_gui_pvc_size',
            'gui_service_type',
            'gui_https_node_port',
            'gui_https_node_port_cmg',
            'gui_https_node_port_cmm',
            'gui_https_node_port_cmgsec',
            'oam_network_name',
            'oam_network_cidr',
            'oam_network_gw_ip',
            'oam_network_start_ip',
            'oam_network_vlan_id',
            'oam_network_bridge',
            'oam_network_bridge_nad',
            'oam_network_rtable_id',
            'sig_network_cidr',
            'sig_network_gw_ip',
            'sig_network_start_ip',
            'sig_network_vlanid',
            'sig_network_bridge',
            'sig_network_bridge_nad',
            'snmp_v3_user',
            'snmp_v3_auth_password',
            'snmp_v3_auth_protocol',
            'snmp_v3_privacy_protocol',
            'cmg_name',
            'cmg_namespace',
            'cmg_uuid',
            'cmg_autonomous_system_number',
            'cmg_base_nodeport_range',
            'cmg_ssh_port',
            'cmg_sys_loopback_ip_with_netmask',
            'cmg_sys_loopback_vlanid',
            'cmg_sig_loopback_ip_with_netmask',
            'cmg_sig_loopback_vlanid',
            'cmg_sig_loopback_mac_address',
            'cmg_lb_port1_ip_with_netmask',
            'cmg_lb_port1_vlanid',
            'cmg_lb_port2_ip_with_netmask',
            'cmg_lb_port2_vlanid',
            'cmg_sriov_enable_dpdk_vlan',
            'cmg_sriov_vf_pool_namespace',
            'cmg_sriov_vf_pool1_name',
            'cmg_sriov_vf_pool1_trust',
            'cmg_sriov_vf_pool2_name',
            'cmg_sriov_vf_pool2_trust',
            'cmg_apn_ip_pool',
            'sec_cmg_name',
            'sec_cmg_namespace',
            'sec_cmg_uuid',
            'sec_cmg_base_nodeport_range',
            'sec_cmg_ssh_port',
            'sec_cmg_sys_loopback_ip_with_netmask',
            'sec_cmg_sys_loopback_vlanid',
            'sec_cmg_sig_loopback_ip_with_netmask',
            'sec_cmg_sig_loopback_vlanid',
            'sec_cmg_lb_port1_ip_with_netmask',
            'sec_cmg_lb_port1_vlanid',
            'sec_cmg_lb_port2_ip_with_netmask',
            'sec_cmg_lb_port2_vlanid',
            'sec_cmg_sriov_vf_pool_namespace',
            'sec_cmg_sriov_vf_pool1_name',
            'sec_cmg_sriov_vf_pool1_trust',
            'sec_cmg_sriov_vf_pool2_name',
            'sec_cmg_sriov_vf_pool2_trust',
            'cmm_name',
            'cmm_namespace',
            'cmm_uuid',
            'apc_name',
            'apc_namespace',
            'apc_spr_sync_enable',
            'apc_spr_sync_remote_sap_sig_ip'
        ]


class CMUProfileFilterForm(NetBoxModelFilterSetForm):
    model = CMUProfile
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class CMUProfileCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = CMUProfile
        fields = [
            'name',
            'description',
            'cmu_deployment_mode',
            'cmu_varient',
            'cmu_timezone',
            'cmu_imageregistry',
            'cmu_image_repository',
            'cmu_imageregistry_pullsecret',
            'cmu_qcow_http_server',
            'cmu_qcow_relative_path',
            'cmu_bastion_server',
            'cmu_ext_ntp_ip_1',
            'cmu_ext_ntp_ip_2',
            'cmu_ext_nameserver_ip_list',
            'cmu_nsp_management_ip',
            'system_namespace',
            'system_service_account_name',
            'system_service_type',
            'system_storage_class_name',
            'system_image_name',
            'system_image_tag',
            'gui_replica_count',
            'gui_namespace',
            'gui_storage_class_name',
            'gui_service_account_name',
            'gui_cassandra_image_name',
            'gui_cassandra_image_tag',
            'gui_cassandra_pod_cpu',
            'gui_cassandra_pod_memory',
            'gui_cassandra_pvc_size',
            'gui_cmupfm_image_name',
            'gui_cmupfm_image_tag',
            'gui_cmupfm_pod_cpu',
            'gui_cmupfm_pod_memory',
            'gui_consoles_image_name',
            'gui_consoles_image_tag',
            'gui_gui_image_name',
            'gui_gui_image_tag',
            'gui_gui_pvc_size',
            'gui_service_type',
            'gui_https_node_port',
            'gui_https_node_port_cmg',
            'gui_https_node_port_cmm',
            'gui_https_node_port_cmgsec',
            'oam_network_name',
            'oam_network_cidr',
            'oam_network_gw_ip',
            'oam_network_start_ip',
            'oam_network_vlan_id',
            'oam_network_bridge',
            'oam_network_bridge_nad',
            'oam_network_rtable_id',
            'sig_network_cidr',
            'sig_network_gw_ip',
            'sig_network_start_ip',
            'sig_network_vlanid',
            'sig_network_bridge',
            'sig_network_bridge_nad',
            'snmp_v3_user',
            'snmp_v3_auth_password',
            'snmp_v3_auth_protocol',
            'snmp_v3_privacy_protocol',
            'cmg_name',
            'cmg_namespace',
            'cmg_uuid',
            'cmg_autonomous_system_number',
            'cmg_base_nodeport_range',
            'cmg_ssh_port',
            'cmg_sys_loopback_ip_with_netmask',
            'cmg_sys_loopback_vlanid',
            'cmg_sig_loopback_ip_with_netmask',
            'cmg_sig_loopback_vlanid',
            'cmg_sig_loopback_mac_address',
            'cmg_lb_port1_ip_with_netmask',
            'cmg_lb_port1_vlanid',
            'cmg_lb_port2_ip_with_netmask',
            'cmg_lb_port2_vlanid',
            'cmg_sriov_enable_dpdk_vlan',
            'cmg_sriov_vf_pool_namespace',
            'cmg_sriov_vf_pool1_name',
            'cmg_sriov_vf_pool1_trust',
            'cmg_sriov_vf_pool2_name',
            'cmg_sriov_vf_pool2_trust',
            'cmg_apn_ip_pool',
            'sec_cmg_name',
            'sec_cmg_namespace',
            'sec_cmg_uuid',
            'sec_cmg_base_nodeport_range',
            'sec_cmg_ssh_port',
            'sec_cmg_sys_loopback_ip_with_netmask',
            'sec_cmg_sys_loopback_vlanid',
            'sec_cmg_sig_loopback_ip_with_netmask',
            'sec_cmg_sig_loopback_vlanid',
            'sec_cmg_lb_port1_ip_with_netmask',
            'sec_cmg_lb_port1_vlanid',
            'sec_cmg_lb_port2_ip_with_netmask',
            'sec_cmg_lb_port2_vlanid',
            'sec_cmg_sriov_vf_pool_namespace',
            'sec_cmg_sriov_vf_pool1_name',
            'sec_cmg_sriov_vf_pool1_trust',
            'sec_cmg_sriov_vf_pool2_name',
            'sec_cmg_sriov_vf_pool2_trust',
            'cmm_name',
            'cmm_namespace',
            'cmm_uuid',
            'apc_name',
            'apc_namespace',
            'apc_spr_sync_enable',
            'apc_spr_sync_remote_sap_sig_ip'
        ]


class CMUProfileBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    ) 
    model = CMUProfile
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )


