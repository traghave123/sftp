from netbox.graphql.types import NetBoxObjectType
from nokia_siteplanner import filtersets, models
from graphene.types import generic

__all__ = (
    'GnodebType',
    'CUType',
    'DUType',
    'CMUType',
    'CMUProfileType'
)

# Gnodeb Account Type
class GnodebType(NetBoxObjectType):

    class Meta:
        model = models.Gnodeb
        fields = '__all__'
        filterset_class = filtersets.GnodebFilterSet
        
        
# CU Account Type
class CUType(NetBoxObjectType):

    class Meta:
        model = models.CU
        fields = '__all__'
        filterset_class = filtersets.CUFilterSet
        
# DU Account Type
class DUType(NetBoxObjectType):

    class Meta:
        model = models.DU
        fields = '__all__'
        filterset_class = filtersets.DUFilterSet

# CMU Account Type
class CMUType(NetBoxObjectType):

    class Meta:
        model = models.CMU
        fields = '__all__'
        filterset_class = filtersets.CMUFilterSet



# CMU Account Type
class CMUProfileType(NetBoxObjectType):
  
    class Meta:
        model = models.CMUProfile
        fields = '__all__'
        filterset_class = filtersets.CMUProfileFilterSet

