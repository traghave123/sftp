from .schema import CMUCloudQuery
schema = CMUCloudQuery
