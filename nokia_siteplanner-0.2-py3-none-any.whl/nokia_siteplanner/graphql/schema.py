import graphene
from netbox.graphql.fields import ObjectField, ObjectListField
from .types import CMUType, CMUProfileType, GnodebType, CUType, DUType

class CMUCloudQuery(graphene.ObjectType):
    
    gnodeb = ObjectField(GnodebType)
    gnodeb_list = ObjectListField(GnodebType)
    
    cu = ObjectField(CUType)
    cu_list = ObjectField(CUType)
    
    du = ObjectField(DUType)
    du_list = ObjectField(DUType)
    
    # CMU account type
    cmu = ObjectField(CMUType)
    cmu_list = ObjectListField(CMUType)

    cmuprofile = ObjectField(CMUProfileType)
    cmuprofile_list = ObjectListField(CMUProfileType)


