from nfvi_automation.template_content import AutomationExtensions
from .automation import *

template_extensions = []

class CMUAutomationExtensions(AutomationExtensions):
    metadata = cmu_metadata
    model = 'nokia_siteplanner.cmu'

class GnodebAutomationExtensions(AutomationExtensions):
    metadata = gnodeb_metadata
    model = 'nokia_siteplanner.gnodeb'

template_extensions.append(CMUAutomationExtensions)
template_extensions.append(GnodebAutomationExtensions)

