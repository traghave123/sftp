from oauth.plugins.permissions import OAuthPermissionExtension
from .models import CMU, CMUProfile, Gnodeb , CU, DU

class CMUOAuthPermissionExtensions(OAuthPermissionExtension):
  
    def add_to_cloud_read_perm(self):
      return [ CMU, CMUProfile, Gnodeb , CU, DU]

    def add_to_cloud_write_perm(self):
      return [ CMU, CMUProfile, Gnodeb , CU, DU]
      

permission_extensions = CMUOAuthPermissionExtensions()
