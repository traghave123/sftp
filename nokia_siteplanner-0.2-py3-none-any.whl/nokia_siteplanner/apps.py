from django.apps import AppConfig


class CMUNetboxConfig(AppConfig):
    name = "nokia_siteplanner"
    verbose_name = "CMU Siteplanner"
