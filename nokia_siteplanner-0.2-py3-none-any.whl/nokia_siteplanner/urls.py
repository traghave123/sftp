from django.urls import path
from extras.plugins.utils import get_url_extensions
from netbox.views.generic import ObjectChangeLogView, ObjectJournalView
from .automation import *
from nfvi_automation.views import AutomationContextProcessView
from . import views
from .models import CMU, CMUProfile, Gnodeb, CU, DU

app_name = 'plugins:nokia_siteplanner'
urlpatterns = [
    
    #Gnodeb
    path('gnodebs/', views.GnodebListView.as_view(), name='gnodeb_list'),
    path('gnodebs/add/', views.GnodebAddView.as_view(), name='gnodeb_add'),
    path('gnodebs/import/', views.GnodebBulkImportView.as_view(), name='gnodeb_import'),
    path('gnodebs/delete/', views.GnodebBulkDeleteView.as_view(), name='gnodeb_bulk_delete'),
    path('gnodebs/<int:pk>/', views.GnodebView.as_view(), name='gnodeb'),
    path('gnodebs/<int:pk>/edit/', views.GnodebEditView.as_view(), name='gnodeb_edit'),
    path('gnodebs/<int:pk>/delete/', views.GnodebDeleteView.as_view(), name='gnodeb_delete'),
    path('gnodebs<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='gnodeb_changelog', kwargs={'model': Gnodeb}),
    
    #CU
    path('cus/', views.CUListView.as_view(), name='cu_list'),
    path('cus/add/', views.CUAddView.as_view(), name='cu_add'),
    path('cus/import/', views.CUBulkImportView.as_view(), name='cu_import'),
    path('cus/delete/', views.CUBulkDeleteView.as_view(), name='cu_bulk_delete'),
    path('cu/<int:pk>/', views.CUView.as_view(), name='cu'),
    path('cu/<int:pk>/edit/', views.CUEditView.as_view(), name='cu_edit'),
    path('cu/<int:pk>/delete/', views.CUDeleteView.as_view(), name='cu_delete'),
    path('cu<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='cu_changelog', kwargs={'model': CU}),
    
    #DU
    path('du/', views.DUListView.as_view(), name='du_list'),
    path('du/add/', views.DUAddView.as_view(), name='du_add'),
    path('du/import/', views.DUBulkImportView.as_view(), name='du_import'),
    path('du/delete/', views.DUBulkDeleteView.as_view(), name='du_bulk_delete'),
    path('du/<int:pk>/', views.DUView.as_view(), name='du'),
    path('du/<int:pk>/edit/', views.DUEditView.as_view(), name='du_edit'),
    path('du/<int:pk>/delete/', views.DUDeleteView.as_view(), name='du_delete'),
    path('du<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='du_changelog', kwargs={'model': DU}),

    path('cmus/', views.CMUListView.as_view(), name='cmu_list'),
    path('cmus/add/', views.CMUAddView.as_view(), name='cmu_add'),
    path('cmus/import/', views.CMUBulkImportView.as_view(), name='cmu_import'),
    path('cmus/delete/', views.CMUBulkDeleteView.as_view(), name='cmu_bulk_delete'),
    path('cmus/<int:pk>/', views.CMUView.as_view(), name='cmu'),
    path('cmus/<int:pk>/edit/', views.CMUEditView.as_view(), name='cmu_edit'),
    path('cmus/<int:pk>/delete/', views.CMUDeleteView.as_view(), name='cmu_delete'),
    path('cmus<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='cmu_changelog', kwargs={'model': CMU}),


    path('cmuprofiles/', views.CMUProfileListView.as_view(), name='cmuprofile_list'),
    path('cmuprofiles/add/', views.CMUProfileAddView.as_view(), name='cmuprofile_add'),
    path('cmuprofiles/import/', views.CMUProfileBulkImportView.as_view(), name='cmuprofile_import'),
    path('cmuprofiles/delete/', views.CMUProfileBulkDeleteView.as_view(), name='cmuprofile_bulk_delete'),
    path('cmuprofiles/<int:pk>/', views.CMUProfileView.as_view(), name='cmuprofile'),
    path('cmuprofiles/<int:pk>/edit/', views.CMUProfileEditView.as_view(), name='cmuprofile_edit'),
    path('cmuprofiles/<int:pk>/delete/', views.CMUProfileDeleteView.as_view(), name='cmuprofile_delete'),
    path('cmuprofiles<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='cmuprofile_changelog', kwargs={'model': CMUProfile}),


    path(f'{gnodeb_metadata.automation_url_prefix}/<int:object_pk>/automation/',  AutomationContextProcessView.as_view(), name=gnodeb_metadata.get_automation_view_name(), kwargs={'metadata': gnodeb_metadata}),
    path(f'{cu_metadata.automation_url_prefix}/<int:object_pk>/automation/',  AutomationContextProcessView.as_view(), name=cu_metadata.get_automation_view_name(), kwargs={'metadata': cu_metadata}),
    path(f'{du_metadata.automation_url_prefix}/<int:object_pk>/automation/',  AutomationContextProcessView.as_view(), name=du_metadata.get_automation_view_name(), kwargs={'metadata': du_metadata}),
    path(f'{cmu_metadata.automation_url_prefix}/<int:object_pk>/automation/',  AutomationContextProcessView.as_view(), name=cmu_metadata.get_automation_view_name(), kwargs={'metadata': cmu_metadata}),
    *get_url_extensions(app_name),
]
