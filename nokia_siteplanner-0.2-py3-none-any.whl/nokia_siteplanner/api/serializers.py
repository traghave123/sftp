from netbox.api.serializers import NetBoxModelSerializer
from nokia_siteplanner.models import CMU, CMUProfile, Gnodeb, CU, DU
from .nested_serializers import *
from netbox.api import WritableNestedSerializer, SerializedPKRelatedField
from virtualization.api.nested_serializers import NestedClusterSerializer
from nfvi_management.api.serializers import NestedVirtualInfrastructureSerializer
from utilities_siteplanner.api.nested_serializers import NestedImageRegistrySerializer, NestedHttpServerSerializer
from dcim.api.nested_serializers import NestedDeviceSerializer

from rest_framework import serializers

class GnodebSerializer(NetBoxModelSerializer):
    
    virtual_infrastructure = NestedVirtualInfrastructureSerializer(required=False, allow_null=True)
    netact_instance_name = NestedDeviceSerializer(required=False, allow_null=True)

    class Meta:
        model = Gnodeb
        fields = ('id', 'name', 'description', 'netact_instance_name', 'tags', 'virtual_infrastructure')
    
    def create(self, validated_data):
        return Gnodeb.objects.create(**validated_data)
    
class CUSerializer(NetBoxModelSerializer):
    container_imageregistry = NestedImageRegistrySerializer(required=False, allow_null=True)
    class Meta:
        model = CU
        fields = ['id', 'name', 'description', 'namespace', 'cluster','container_imageregistry', 'configuration_software_id', 'release_name', 'nerel_id', 
                  'secrets', 'vcu_profile_name', 'chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version']
        
    def create(self, validated_data):
        return CU.objects.create(**validated_data)
    
class DUSerializer(NetBoxModelSerializer):
    container_imageregistry = NestedImageRegistrySerializer(required=False, allow_null=True)
    class Meta:
        model = DU
        fields = ['id', 'name', 'description', 'namespace', 'cluster','container_imageregistry', 'configuration_software_id', 'release_name', 'nerel_id', 
                  'secrets', 'vdu_profile_name', 'chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version',
                  'nop_name', 'nop_description', 'nop_namespace', 'nop_container_imageregistry', 'nop_configuration_software_id', 'nop_release_name',
                  'nop_secrets','nop_vdu_profile_name', 'nop_chart_version']

    def create(self, validated_data):
        return DU.objects.create(**validated_data)

class CMUSerializer(NetBoxModelSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='nokia_siteplanner:cmu-detail')
    cmu_cluster = NestedClusterSerializer(required=False, allow_null=True)
    cmu_profile = NestedCMUProfileSerializer(required=False, allow_null=True)
    cmu_imageregistry = NestedImageRegistrySerializer(required=False, allow_null=True)
    cmu_qcow_http_server = NestedHttpServerSerializer(required=False, allow_null=True)

    class Meta:
        model = CMU
        fields = ('id', 'name', 'description', 'cmu_cluster', 'cmu_profile', 'cmu_deployment_mode', 'cmu_varient', 'cmu_timezone', 'cmu_imageregistry', 'cmu_image_repository', 'cmu_imageregistry_pullsecret', 'cmu_qcow_http_server', 'cmu_qcow_relative_path', 'cmu_bastion_server', 'cmu_ext_ntp_ip_1', 'cmu_ext_ntp_ip_2', 'cmu_ext_nameserver_ip_list', 'cmu_nsp_management_ip', 'system_namespace', 'system_service_account_name', 'system_service_type', 'system_storage_class_name', 'system_image_name', 'system_image_tag', 'gui_replica_count', 'gui_namespace', 'gui_storage_class_name', 'gui_service_account_name', 'gui_cassandra_image_name', 'gui_cassandra_image_tag', 'gui_cassandra_pod_cpu', 'gui_cassandra_pod_memory', 'gui_cassandra_pvc_size', 'gui_cmupfm_image_name', 'gui_cmupfm_image_tag', 'gui_cmupfm_pod_cpu', 'gui_cmupfm_pod_memory', 'gui_consoles_image_name', 'gui_consoles_image_tag', 'gui_gui_image_name', 'gui_gui_image_tag', 'gui_gui_pvc_size', 'gui_service_type', 'gui_https_node_port', 'gui_https_node_port_cmg', 'gui_https_node_port_cmm', 'gui_https_node_port_cmgsec', 'oam_network_name', 'oam_network_cidr', 'oam_network_gw_ip', 'oam_network_start_ip', 'oam_network_vlan_id', 'oam_network_bridge', 'oam_network_bridge_nad', 'oam_network_rtable_id', 'sig_network_cidr', 'sig_network_gw_ip', 'sig_network_start_ip', 'sig_network_vlanid', 'sig_network_bridge', 'sig_network_bridge_nad', 'snmp_v3_user', 'snmp_v3_auth_password', 'snmp_v3_auth_protocol', 'snmp_v3_privacy_protocol', 'cmg_name', 'cmg_namespace', 'cmg_uuid', 'cmg_autonomous_system_number', 'cmg_base_nodeport_range', 'cmg_ssh_port', 'cmg_sys_loopback_ip_with_netmask', 'cmg_sig_loopback_ip_with_netmask', 'cmg_sig_loopback_mac_address', 'cmg_lb_port1_ip_with_netmask', 'cmg_lb_port1_vlanid', 'cmg_lb_port2_ip_with_netmask', 'cmg_lb_port2_vlanid', 'cmg_sys_loopback_vlanid', 'cmg_sig_loopback_vlanid', 'cmg_sriov_enable_dpdk_vlan', 'cmg_sriov_vf_pool_namespace', 'cmg_sriov_vf_pool1_name', 'cmg_sriov_vf_pool1_trust', 'cmg_sriov_vf_pool2_name', 'cmg_sriov_vf_pool2_trust', 'cmg_apn_ip_pool', 'sec_cmg_name', 'sec_cmg_namespace', 'sec_cmg_uuid', 'sec_cmg_base_nodeport_range', 'sec_cmg_ssh_port', 'sec_cmg_sys_loopback_ip_with_netmask', 'sec_cmg_sig_loopback_ip_with_netmask', 'sec_cmg_lb_port1_ip_with_netmask', 'sec_cmg_lb_port1_vlanid', 'sec_cmg_lb_port2_ip_with_netmask', 'sec_cmg_lb_port2_vlanid', 'sec_cmg_sys_loopback_vlanid', 'sec_cmg_sig_loopback_vlanid', 'sec_cmg_sriov_vf_pool_namespace', 'sec_cmg_sriov_vf_pool1_name', 'sec_cmg_sriov_vf_pool1_trust', 'sec_cmg_sriov_vf_pool2_name', 'sec_cmg_sriov_vf_pool2_trust', 'cmm_name', 'cmm_namespace', 'cmm_uuid', 'apc_name', 'apc_namespace', 'apc_spr_sync_enable', 'apc_spr_sync_remote_sap_sig_ip', 'tags')
    
    def create(self, validated_data):
        return CMU.objects.create(**validated_data)

class CMUProfileSerializer(NetBoxModelSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='nokia_siteplanner:cmuprofile-detail')
    cmu_imageregistry = NestedImageRegistrySerializer(required=False, allow_null=True)
    cmu_qcow_http_server = NestedHttpServerSerializer(required=False, allow_null=True)
    class Meta:
        model = CMUProfile
        fields = ('id', 'name', 'description', 'cmu_deployment_mode', 'cmu_varient', 'cmu_timezone', 'cmu_imageregistry', 'cmu_image_repository', 'cmu_imageregistry_pullsecret', 'cmu_qcow_http_server', 'cmu_qcow_relative_path', 'cmu_bastion_server', 'cmu_ext_ntp_ip_1', 'cmu_ext_ntp_ip_2', 'cmu_ext_nameserver_ip_list', 'cmu_nsp_management_ip', 'system_namespace', 'system_service_account_name', 'system_service_type', 'system_storage_class_name', 'system_image_name', 'system_image_tag', 'gui_replica_count', 'gui_namespace', 'gui_storage_class_name', 'gui_service_account_name', 'gui_cassandra_image_name', 'gui_cassandra_image_tag', 'gui_cassandra_pod_cpu', 'gui_cassandra_pod_memory', 'gui_cassandra_pvc_size', 'gui_cmupfm_image_name', 'gui_cmupfm_image_tag', 'gui_cmupfm_pod_cpu', 'gui_cmupfm_pod_memory', 'gui_consoles_image_name', 'gui_consoles_image_tag', 'gui_gui_image_name', 'gui_gui_image_tag', 'gui_gui_pvc_size', 'gui_service_type', 'gui_https_node_port', 'gui_https_node_port_cmg', 'gui_https_node_port_cmm', 'gui_https_node_port_cmgsec', 'oam_network_name', 'oam_network_cidr', 'oam_network_gw_ip', 'oam_network_start_ip', 'oam_network_vlan_id', 'oam_network_bridge', 'oam_network_bridge_nad', 'oam_network_rtable_id', 'sig_network_cidr', 'sig_network_gw_ip', 'sig_network_start_ip', 'sig_network_vlanid', 'sig_network_bridge', 'sig_network_bridge_nad', 'snmp_v3_user', 'snmp_v3_auth_password', 'snmp_v3_auth_protocol', 'snmp_v3_privacy_protocol', 'cmg_name', 'cmg_namespace', 'cmg_uuid', 'cmg_autonomous_system_number', 'cmg_base_nodeport_range', 'cmg_ssh_port', 'cmg_sys_loopback_ip_with_netmask', 'cmg_sig_loopback_ip_with_netmask', 'cmg_sig_loopback_mac_address', 'cmg_lb_port1_ip_with_netmask', 'cmg_lb_port1_vlanid', 'cmg_lb_port2_ip_with_netmask', 'cmg_lb_port2_vlanid', 'cmg_sys_loopback_vlanid', 'cmg_sig_loopback_vlanid', 'cmg_sriov_enable_dpdk_vlan', 'cmg_sriov_vf_pool_namespace', 'cmg_sriov_vf_pool1_name', 'cmg_sriov_vf_pool1_trust', 'cmg_sriov_vf_pool2_name', 'cmg_sriov_vf_pool2_trust', 'cmg_apn_ip_pool', 'sec_cmg_name', 'sec_cmg_namespace', 'sec_cmg_uuid', 'sec_cmg_base_nodeport_range', 'sec_cmg_ssh_port', 'sec_cmg_sys_loopback_ip_with_netmask', 'sec_cmg_sig_loopback_ip_with_netmask', 'sec_cmg_lb_port1_ip_with_netmask', 'sec_cmg_lb_port1_vlanid', 'sec_cmg_lb_port2_ip_with_netmask', 'sec_cmg_lb_port2_vlanid', 'sec_cmg_sys_loopback_vlanid', 'sec_cmg_sig_loopback_vlanid', 'sec_cmg_sriov_vf_pool_namespace', 'sec_cmg_sriov_vf_pool1_name', 'sec_cmg_sriov_vf_pool1_trust', 'sec_cmg_sriov_vf_pool2_name', 'sec_cmg_sriov_vf_pool2_trust', 'cmm_name', 'cmm_namespace', 'cmm_uuid', 'apc_name', 'apc_namespace', 'apc_spr_sync_enable', 'apc_spr_sync_remote_sap_sig_ip', 'tags')

    def create(self, validated_data):
        return CMUProfile.objects.create(**validated_data)  

