from netbox.api.viewsets import NetBoxModelViewSet
from nokia_siteplanner import filtersets
from nokia_siteplanner.models import CMU, CMUProfile, Gnodeb, CU, DU
from rest_framework.routers import APIRootView
from . import serializers

class CMUSiteplannerAPIRootView:
    """
    CMU API root view
    """
    def get_view_name(self):
        return 'CMU Netbox'

__all__ = (
    'GnodebViewSet',
    'CUViewSet',
    'DUViewSet',
    'CMUViewSet',
    'CMUProfileViewSet'
)

class GnodebViewSet(NetBoxModelViewSet):
    serializer_class = serializers.GnodebSerializer
    queryset = Gnodeb.objects.all()
    filterset_class = filtersets.GnodebFilterSet
    
class CUViewSet(NetBoxModelViewSet):
    serializer_class = serializers.CUSerializer
    queryset = CU.objects.all()
    filterset_class = filtersets.CUFilterSet
    
class DUViewSet(NetBoxModelViewSet):
    serializer_class = serializers.DUSerializer
    queryset = DU.objects.all()
    filterset_class = filtersets.DUFilterSet

class CMUViewSet(NetBoxModelViewSet):
    serializer_class = serializers.CMUSerializer
    queryset = CMU.objects.all()
    filterset_class = filtersets.CMUFilterSet


class CMUProfileViewSet(NetBoxModelViewSet):
    serializer_class = serializers.CMUProfileSerializer
    queryset = CMUProfile.objects.all()
    filterset_class = filtersets.CMUProfileFilterSet    

