from rest_framework import serializers
from nokia_siteplanner.models import CMU, CMUProfile, Gnodeb, CU, DU
from netbox.api import WritableNestedSerializer
from virtualization.api.nested_serializers import NestedClusterSerializer
from nfvi_management.api.serializers import NestedVirtualInfrastructureSerializer
from utilities_siteplanner.api.nested_serializers import NestedImageRegistrySerializer
from dcim.api.nested_serializers import NestedDeviceSerializer

__all__ = [
    'NestedGnodebSerializer',
    'NestedCUSerializer',
    'NestedDUSerializer',
    'NestedCMUSerializer',
    'NestedCMUProfileSerializer'
]

class NestedGnodebSerializer(WritableNestedSerializer):
    virtual_infrastructure = NestedVirtualInfrastructureSerializer(required=False, allow_null=True)
    netact_instance_name = NestedDeviceSerializer(required=False, allow_null=True)

    class Meta:
        model = Gnodeb
        fields = ['id', 'name', 'netact_instance_name']
        
class NestedCUSerializer(WritableNestedSerializer):
    cluster = NestedClusterSerializer(required=False, allow_null=True)

    class Meta:
        model = CU
        fields = ['id', 'name', 'description', 'namespace', 'cluster', 'container_imageregistry', 'configuration_software_id', 'release_name', 'nerel_id', 
                'secrets', 'vcu_profile_name','chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version']
        
class NestedDUSerializer(WritableNestedSerializer):
    cluster = NestedClusterSerializer(required=False, allow_null=True)

    class Meta:
        model = DU
        fields = ['id', 'name', 'description', 'namespace', 'cluster', 'container_imageregistry','configuration_software_id', 'release_name', 'nerel_id',
                  'secrets', 'vdu_profile_name','chart_version', 'prerequisites_chart_version', 'cluster_preparation_chart_version',
                  'nop_name', 'nop_description', 'nop_namespace', 'nop_container_imageregistry', 'nop_configuration_software_id', 'nop_release_name', 
                  'nop_secrets','nop_vdu_profile_name', 'nop_chart_version']
        

class NestedCMUProfileSerializer(WritableNestedSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='nokia_siteplanner:cmuprofile-detail')
    cmuprofile_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = CMUProfile
        fields = ['id', 'name', 'cmuprofile_count']

class NestedCMUSerializer(WritableNestedSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='nokia_siteplanner:cmu-detail')
    cmu_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = CMU
        fields = ['id', 'name', 'cmu_count']



