from netbox.api import NetBoxRouter
from . import views

router = NetBoxRouter()

router.register(r'cmus', views.CMUViewSet)
router.register(r'cmuprofiles', views.CMUProfileViewSet)
router.register(r'gnodebs', views.GnodebViewSet)
router.register(r'cus', views.CUViewSet)
router.register(r'dus', views.DUViewSet)

app_name = 'nokia_siteplanner'
urlpatterns = router.urls
