from extras.plugins import PluginConfig
from graphql import *
from extras.plugins.utils import import_object

class CMUSiteplannerConfig(PluginConfig):
    name = 'nokia_siteplanner'
    verbose_name = 'CMU'
    description = 'Nokia 5G Core Network CMU Plugin: CMU'
    version = '0.1'
    base_url = 'nokia_siteplanner'
    required_settings = []
    default_settings = {}
    caching_config = {}
    
    def ready(self):
        super().ready()
        from .automation import cmu_metadata, gnodeb_metadata
        from nfvi_automation.models import ObjectTypeAutomationMetadata
        ObjectTypeAutomationMetadata.register.add(cmu_metadata)
        ObjectTypeAutomationMetadata.register.add(gnodeb_metadata)        
        
config = CMUSiteplannerConfig
default_app_config = 'nokia_siteplanner.config'
