# Simulate Netbox URLs
from netbox.urls import *
