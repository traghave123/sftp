# Borrowing all of the settings used in the nfvi-netbox-plugin project
from nfvi_netbox_plugin.settings import *

ALLOWED_HOSTS = ['*']

# Forcing our plugin to be included
INSTALLED_APPS += ['nokia_siteplanner.config', 'utilities_siteplanner']
PLUGINS += ['nokia_siteplanner', 'utilities_siteplanner']

# Configuring Postgres and Redis to match the docker/example-env environment
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'netbox',
        'USER': 'netbox',
        'PASSWORD': 'netbox',
        'HOST': 'localhost',
        'PORT': '5431',
        'CONN_MAX_AGE': 300,
        'OPTIONS': {
            'sslmode': 'prefer',
        }
    }
}

REDIS = {
    'tasks': {
        'HOST': 'localhost',
        'PORT': 6380,
        'PASSWORD': 'redis',
        'DATABASE': 0,
        'SSL': False,
    },
    'caching': {
        'HOST': 'localhost',
        'PORT': 6380,
        'PASSWORD': 'redis',
        'DATABASE': 1,
        'SSL': False,
    }
}

DEVELOPER = True

DEBUG = True

# Override where static files go
import os
NETBOX_PATH = os.environ.get('NETBOXPATH')
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_ROOT = BASE_DIR + '/static'
STATIC_URL = '/static/'
STATICFILES_DIRS = (
    os.path.join(NETBOX_PATH, 'project-static', 'dist'),
    os.path.join(NETBOX_PATH, 'project-static', 'img'),
    ('docs', os.path.join(NETBOX_PATH, 'project-static', 'docs')),  # Prefix with /docs
)

# CP4NA settings 
PLUGINS_CONFIG['TNC'] = {
    'TNCO_ENV': {
        'ADDRESS': 'https://9.20.196.20',
        'CLIENT_ID': 'LmClient',
        'CLIENT_SECRET': 'admin',
        'SECURE': True,
        #'CLIENT_ID': 'NimrodClient',
        #'CLIENT_SECRET': 'pass123',
        #'USERNAME': 'jack',
        #'PASSWORD': 'jack',
    },
}
