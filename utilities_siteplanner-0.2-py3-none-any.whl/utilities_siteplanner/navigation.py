from extras.plugins import PluginMenu, PluginMenuButton, PluginMenuGroup, PluginMenuItem, ButtonColorChoices

menu_extensions = [
    PluginMenu(
        label='Utilities',
        icon_class='mdi mdi-layers-triple',
        groups=[
            PluginMenuGroup(
                label='UTILITIES',
                items=[
                    PluginMenuItem(
                        link='plugins:utilities_siteplanner:imageregistry_list',
                        link_text='ImageRegistry',
                        permissions=['utilities_siteplanner.view_imageregistry'],
                        buttons=(
                            PluginMenuButton(
                                link='plugins:utilities_siteplanner:imageregistry_add',
                                title='Add',
                                icon_class='mdi mdi-plus-thick',
                                permissions=[
                                    'utilities_siteplanner.add_imageregistry'],
                                color=ButtonColorChoices.GREEN
                            ),
                            PluginMenuButton(
                                link='plugins:utilities_siteplanner:imageregistry_import',
                                title='Import',
                                icon_class='mdi mdi-upload',
                                permissions=[
                                    'utilities_siteplanner.add_imageregistry'],
                                color=ButtonColorChoices.CYAN
                            )
                        )
                    ),
                    PluginMenuItem(
                        link='plugins:utilities_siteplanner:httpserver_list',
                        link_text='HttpServer',
                        permissions=['utilities_siteplanner.view_httpserver'],
                        buttons=(
                            PluginMenuButton(
                                link='plugins:utilities_siteplanner:httpserver_add',
                                title='Add',
                                icon_class='mdi mdi-plus-thick',
                                permissions=[
                                    'utilities_siteplanner.add_httpserver'],
                                color=ButtonColorChoices.GREEN
                            ),
                            PluginMenuButton(
                                link='plugins:utilities_siteplanner:httpserver_import',
                                title='Import',
                                icon_class='mdi mdi-upload',
                                permissions=[
                                    'utilities_siteplanner.add_httpserver'],
                                color=ButtonColorChoices.CYAN
                            )
                        )
                    ),
                    PluginMenuItem(
                        link='plugins:utilities_siteplanner:bastionserver_list',
                        link_text='BastionServer',
                        permissions=['utilities_siteplanner.view_bastionserver'],
                        buttons=(
                            PluginMenuButton(
                                link='plugins:utilities_siteplanner:bastionserver_add',
                                title='Add',
                                icon_class='mdi mdi-plus-thick',
                                permissions=[
                                    'utilities_siteplanner.add_bastionserver'],
                                color=ButtonColorChoices.GREEN
                            ),
                            PluginMenuButton(
                                link='plugins:utilities_siteplanner:bastionserver_import',
                                title='Import',
                                icon_class='mdi mdi-upload',
                                permissions=[
                                    'utilities_siteplanner.add_bastionserver'],
                                color=ButtonColorChoices.CYAN
                            )
                        )
                    )
                ]
            )        
        ]
    )
]
