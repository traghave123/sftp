from netbox.graphql.types import NetBoxObjectType
from utilities_siteplanner import filtersets, models
from graphene.types import generic

__all__ = (
    'ImageRegistryType',
    'HttpServerType',
    'BastionServerType',
)

# ImageRegistry
class ImageRegistryType(NetBoxObjectType):

    class Meta:
        model = models.ImageRegistry
        fields = '__all__'
        filterset_class = filtersets.ImageRegistryFilterSet

# HttpServer
class HttpServerType(NetBoxObjectType):

    class Meta:
        model = models.HttpServer
        fields = '__all__'
        filterset_class = filtersets.HttpServerFilterSet


# BastionServer
class BastionServerType(NetBoxObjectType):

    class Meta:
        model = models.BastionServer
        fields = '__all__'
        filterset_class = filtersets.BastionServerFilterSet

