import graphene
from netbox.graphql.fields import ObjectField, ObjectListField
from .types import ImageRegistryType, HttpServerType, BastionServerType

class UtilitiesCloudQuery(graphene.ObjectType):
    # ImageRegistry 
    imageregistry = ObjectField(ImageRegistryType)
    imageregistry_list = ObjectListField(ImageRegistryType)
    # HttpServer 
    httpserver = ObjectField(HttpServerType)
    httpserver_list = ObjectListField(HttpServerType)
    # BastionServer 
    bastionserver = ObjectField(BastionServerType)
    bastionserver_list = ObjectListField(BastionServerType)


