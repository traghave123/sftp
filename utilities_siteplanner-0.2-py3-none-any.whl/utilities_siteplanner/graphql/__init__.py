from .schema import UtilitiesCloudQuery
schema = UtilitiesCloudQuery
