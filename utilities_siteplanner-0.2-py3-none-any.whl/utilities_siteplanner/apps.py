from django.apps import AppConfig


class UtilitiesNetboxConfig(AppConfig):
    name = "utilities_siteplanner"
    verbose_name = "Utilities Siteplanner"
