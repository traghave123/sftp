import django_tables2 as tables
from netbox.tables import NetBoxTable, columns
from .models import ImageRegistry, HttpServer, BastionServer

__all__ = (
    'ImageRegistryTable',
    'HttpServerTable',
    'BastionServerTable'
)


class ImageRegistryTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:utilities_siteplanner:imageregistry_list'
    )

    class Meta(NetBoxTable.Meta):
        model = ImageRegistry
        fields = (
            'pk', 'name', 'description', 'repo_server_url', 'repo_server_user', 'repo_server_password', 'repo_server_auth', 'repo_server_email', 'tags'
        )
        default_columns = ('pk', 'name', 'description')


class HttpServerTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:utilities_siteplanner:httpserver_list'
    )    

    class Meta(NetBoxTable.Meta):
        model = HttpServer
        fields = (
            'pk', 'name', 'description', 'http_base_url', 'http_root_dir', 'http_port', 'http_basic_auth', 'tags'
        )
        default_columns = ('pk', 'name', 'description')


class BastionServerTable(NetBoxTable):
    name = tables.Column(
        linkify=True
    )
    description = tables.Column(
        verbose_name='Description'
    )
    tags = columns.TagColumn(
        url_name='plugins:utilities_siteplanner:bastionserver_list'
    )

    class Meta(NetBoxTable.Meta):
        model = BastionServer
        fields = (
            'pk', 'name', 'description', 'bastion_ssh_ip', 'bastion_ssh_port', 'bastion_ssh_user', 'bastion_ssh_password', 'bastion_ssh_auth', 'bastion_ssh_key', 'tags'
        )
        default_columns = ('pk', 'name', 'description')
