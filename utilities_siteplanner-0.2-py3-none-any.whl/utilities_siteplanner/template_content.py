from nfvi_automation.template_content import AutomationExtensions
from .automation import *

template_extensions = []


