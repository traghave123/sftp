import django_filters
from django.db.models import Q
from netbox.filtersets import NetBoxModelFilterSet
from .models import ImageRegistry, HttpServer, BastionServer

__all__ = (
    'ImageRegistryFilterSet',
    'HttpServerFilterSet',
    'BastionServerFilterSet',
)

# Image Registry
class ImageRegistryFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search'
    )
    
    class Meta:
        model = ImageRegistry
        fields = [
            'id',
            'name',
            'description'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) | 
            Q(description__icontains=value)
        )

# Http Server
class HttpServerFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search'
    )

    class Meta:
        model = HttpServer
        fields = [
            'id',
            'name',
            'description'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) |
            Q(description__icontains=value)
        )


# Bastion Server
class BastionServerFilterSet(NetBoxModelFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search'
    )

    class Meta:
        model = BastionServer
        fields = [
            'id',
            'name',
            'description'
        ]

    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) |
            Q(description__icontains=value)
        )
