from nfvi_automation.models.object_type_metadata import ObjectTypeAutomationMetadata
from .models import ImageRegistry, HttpServer, BastionServer





