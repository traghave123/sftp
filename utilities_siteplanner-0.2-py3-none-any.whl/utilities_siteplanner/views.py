import logging

from netbox.views import generic
from . import filtersets, forms, tables
from django.shortcuts import render
from .models import ImageRegistry, HttpServer, BastionServer




#
# ImageRegistrys
#

class ImageRegistryListView(generic.ObjectListView):
    queryset = ImageRegistry.objects.all()
    table = tables.ImageRegistryTable


class ImageRegistryView(generic.ObjectView):
    queryset = ImageRegistry.objects.all()

class ImageRegistryEditView(generic.ObjectEditView):
    queryset = ImageRegistry.objects.all()
    form = forms.ImageRegistryForm

class ImageRegistryAddView(generic.ObjectEditView):
    queryset = ImageRegistry.objects.all()
    form = forms.ImageRegistryForm

class ImageRegistryDeleteView(generic.ObjectDeleteView):
    queryset = ImageRegistry.objects.all()


class ImageRegistryBulkImportView(generic.BulkImportView):
    queryset = ImageRegistry.objects.all()
    model_form = forms.ImageRegistryCSVForm
    table = tables.ImageRegistryTable

class ImageRegistryBulkEditView(generic.BulkEditView):
    queryset = ImageRegistry.objects.all()
    filterset = filtersets.ImageRegistryFilterSet
    table = tables.ImageRegistryTable
    form = forms.ImageRegistryBulkEditForm

class ImageRegistryBulkDeleteView(generic.BulkDeleteView):
    queryset = ImageRegistry.objects.all()
    filterset = filtersets.ImageRegistryFilterSet
    table = tables.ImageRegistryTable



#
# HttpServers
#

class HttpServerListView(generic.ObjectListView):
    queryset = HttpServer.objects.all()
    table = tables.HttpServerTable


class HttpServerView(generic.ObjectView):
    queryset = HttpServer.objects.all()

class HttpServerEditView(generic.ObjectEditView):
    queryset = HttpServer.objects.all()
    form = forms.HttpServerForm

class HttpServerAddView(generic.ObjectEditView):
    queryset = HttpServer.objects.all()
    form = forms.HttpServerForm

class HttpServerDeleteView(generic.ObjectDeleteView):
    queryset = HttpServer.objects.all()


class HttpServerBulkImportView(generic.BulkImportView):
    queryset = HttpServer.objects.all()
    model_form = forms.HttpServerCSVForm
    table = tables.HttpServerTable

class HttpServerBulkEditView(generic.BulkEditView):
    queryset = HttpServer.objects.all()
    filterset = filtersets.HttpServerFilterSet
    table = tables.HttpServerTable
    form = forms.HttpServerBulkEditForm

class HttpServerBulkDeleteView(generic.BulkDeleteView):
    queryset = HttpServer.objects.all()
    filterset = filtersets.HttpServerFilterSet
    table = tables.HttpServerTable


#
# BastionServers
#

class BastionServerListView(generic.ObjectListView):
    queryset = BastionServer.objects.all()
    table = tables.BastionServerTable


class BastionServerView(generic.ObjectView):
    queryset = BastionServer.objects.all()

class BastionServerEditView(generic.ObjectEditView):
    queryset = BastionServer.objects.all()
    form = forms.BastionServerForm

class BastionServerAddView(generic.ObjectEditView):
    queryset = BastionServer.objects.all()
    form = forms.BastionServerForm

class BastionServerDeleteView(generic.ObjectDeleteView):
    queryset = BastionServer.objects.all()


class BastionServerBulkImportView(generic.BulkImportView):
    queryset = BastionServer.objects.all()
    model_form = forms.BastionServerCSVForm
    table = tables.BastionServerTable

class BastionServerBulkEditView(generic.BulkEditView):
    queryset = BastionServer.objects.all()
    filterset = filtersets.BastionServerFilterSet
    table = tables.BastionServerTable
    form = forms.BastionServerBulkEditForm

class BastionServerBulkDeleteView(generic.BulkDeleteView):
    queryset = BastionServer.objects.all()
    filterset = filtersets.BastionServerFilterSet
    table = tables.BastionServerTable
