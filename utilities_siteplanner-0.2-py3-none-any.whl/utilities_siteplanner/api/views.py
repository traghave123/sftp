from netbox.api.viewsets import NetBoxModelViewSet
from utilities_siteplanner import filtersets
from utilities_siteplanner.models import ImageRegistry, HttpServer, BastionServer
from rest_framework.routers import APIRootView
from . import serializers

class UtilitiesSiteplannerAPIRootView:
    """
    Utilities API root view
    """
    def get_view_name(self):
        return 'Utilities Netbox'

__all__ = (
    'ImageRegistryViewSet',
    'HttpServerViewSet',
    'BastionServerViewSet',
)

class ImageRegistryViewSet(NetBoxModelViewSet):
    serializer_class = serializers.ImageRegistrySerializer
    queryset = ImageRegistry.objects.all()
    filterset_class = filtersets.ImageRegistryFilterSet

class HttpServerViewSet(NetBoxModelViewSet):
    serializer_class = serializers.HttpServerSerializer
    queryset = HttpServer.objects.all()
    filterset_class = filtersets.HttpServerFilterSet

class BastionServerViewSet(NetBoxModelViewSet):
    serializer_class = serializers.BastionServerSerializer
    queryset = BastionServer.objects.all()
    filterset_class = filtersets.BastionServerFilterSet

