from netbox.api.serializers import NetBoxModelSerializer
from utilities_siteplanner.models import ImageRegistry, HttpServer, BastionServer
from .nested_serializers import *
from netbox.api import WritableNestedSerializer, SerializedPKRelatedField

from rest_framework import serializers

class ImageRegistrySerializer(NetBoxModelSerializer):

    #url = serializers.HyperlinkedIdentityField(view_name='utilities_siteplanner:imageregistry-detail')
    class Meta:
        model = ImageRegistry
        fields = ('id', 'name', 'description', 'repo_server_url', 'repo_server_user', 'repo_server_password', 'repo_server_auth', 'repo_server_email', 'tags', 'custom_fields' )
    
    def create(self, validated_data):
        return ImageRegistry.objects.create(**validated_data)

class HttpServerSerializer(NetBoxModelSerializer):

    #url = serializers.HyperlinkedIdentityField(view_name='utilities_siteplanner:httpserver-detail')
    class Meta:
        model = HttpServer
        fields = ('id', 'name', 'description', 'http_base_url', 'http_root_dir', 'http_port', 'http_user', 'http_password', 'http_basic_auth', 'tags', 'custom_fields' )

    def create(self, validated_data):
        return HttpServer.objects.create(**validated_data)


class BastionServerSerializer(NetBoxModelSerializer):

    #url = serializers.HyperlinkedIdentityField(view_name='utilities_siteplanner:bastionserver-detail')
    class Meta:
        model = BastionServer
        fields = ('id', 'name', 'description', 'bastion_ssh_ip', 'bastion_ssh_port', 'bastion_ssh_user', 'bastion_ssh_password', 'bastion_ssh_auth', 'bastion_ssh_key', 'tags', 'custom_fields' )

    def create(self, validated_data):
        return BastionServer.objects.create(**validated_data)
