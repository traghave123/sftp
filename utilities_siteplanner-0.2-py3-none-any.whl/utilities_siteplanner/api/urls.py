from netbox.api import NetBoxRouter
from . import views

router = NetBoxRouter()

router.register(r'imageregistrys', views.ImageRegistryViewSet)
router.register(r'httpservers', views.HttpServerViewSet)
router.register(r'bastionservers', views.BastionServerViewSet)

app_name = 'utilities_siteplanner'
urlpatterns = router.urls
