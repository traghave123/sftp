from rest_framework import serializers
from utilities_siteplanner.models import ImageRegistry, HttpServer, BastionServer
from netbox.api import WritableNestedSerializer


__all__ = [
    'NestedImageRegistrySerializer',
    'NestedHttpServerSerializer',
    'NestedBastionServerSerializer',
]

class NestedImageRegistrySerializer(WritableNestedSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='utilities_siteplanner:imageregistry-detail')
    imageregistry_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = ImageRegistry
        fields = ['id', 'name', 'imageregistry_count']


class NestedHttpServerSerializer(WritableNestedSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='utilities_siteplanner:httpserver-detail')
    httpserver_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = HttpServer
        fields = ['id', 'name', 'httpserver_count']


class NestedBastionServerSerializer(WritableNestedSerializer):
    #url = serializers.HyperlinkedIdentityField(view_name='utilities_siteplanner:bastionserver-detail')
    bastionserver_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = BastionServer
        fields = ['id', 'name', 'bastionserver_count']
