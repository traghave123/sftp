from django.core.exceptions import ValidationError
from django.core.validators import (MaxValueValidator, MinValueValidator)
from django.db import models
from django.urls import reverse
from netbox.models import NetBoxModel
import taggit.managers


__all__ = (
    'ImageRegistry',
    'HttpServer',
    'BastionServer'
)


class ImageRegistry(NetBoxModel):
    """
    ImageRegistry Model
    """

    name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Name")
    description = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Description")
    repo_server_url = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name="URL", help_text="Ex: cmu-image-registry.domain.com:5000")
    repo_server_user = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="User", help_text="Either provide User/Password OR Auth")
    repo_server_password = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="Password")
    repo_server_auth = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Auth Info")
    repo_server_email = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Email")
    #repo_server_vm = models.ForeignKey(to='virtualization.VirtualMachine', on_delete=models.CASCADE, related_name='reposervervm', null=False,  blank=True, verbose_name="Repo Server VM" )
    tags = taggit.managers.TaggableManager(through='extras.TaggedItem', blank=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'ImageRegistry'
        verbose_name_plural = 'ImageRegistrys'
        unique_together={('name', 'system_tenant_id') }

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:utilities_siteplanner:imageregistry', args=[self.pk])

    def validate_data(self):
        if self.name == '':
            raise ValidationError('Name must be provided for a Image Registry')


class HttpServer(NetBoxModel):
    """
    HttpServer Model
    """

    name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Name")
    description = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Description")
    http_base_url = models.CharField(max_length=100, blank=False, null=False, unique=False, verbose_name="Http(s) Base URL", help_text="Ex: http://9.9.9.9")
    http_root_dir = models.CharField(max_length=64, default="/var/www/html", blank=True, null=False, unique=False, verbose_name="Root Directory")
    http_port = models.PositiveBigIntegerField(default=22, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="Http(s) Port")
    http_user = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="User", help_text="Optionally provide either user/password or auth info")
    http_password = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="Password")
    http_basic_auth = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Basic Auth Info")
    #http_server_vm = models.ForeignKey(to='virtualization.VirtualMachine', on_delete=models.CASCADE, related_name='httpservervm', null=False,  blank=True, verbose_name="Http(s) Server VM" )
    tags = taggit.managers.TaggableManager(through='extras.TaggedItem', blank=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'HttpServer'
        verbose_name_plural = 'HttpServers'
        unique_together={('name', 'system_tenant_id') }

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:utilities_siteplanner:httpserver', args=[self.pk])

    def validate_data(self):
        if self.name == '':
            raise ValidationError('Name must be provided for a Http Server')


class BastionServer(NetBoxModel):
    """
    BastionServer Model
    """

    name = models.CharField(max_length=64, blank=False, null=False, unique=False, verbose_name="Name")
    description = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Description")
    bastion_ssh_ip = models.CharField(max_length=32, blank=False, null=False, unique=False, verbose_name="IP Address", help_text="Ex: 9.10.10.20")
    bastion_ssh_port = models.PositiveBigIntegerField(default=22, validators=[MinValueValidator(1), MaxValueValidator(65535)], blank=True, null=False, unique=False, verbose_name="SSH Port")
    bastion_ssh_user = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="User", help_text="Either provide user/password or auth or user/key")
    bastion_ssh_password = models.CharField(max_length=64, blank=True, null=False, unique=False, verbose_name="Password")
    bastion_ssh_auth = models.CharField(max_length=100, blank=True, null=False, unique=False, verbose_name="Auth Info")
    bastion_ssh_key = models.CharField(max_length=1000, blank=True, null=False, unique=False, verbose_name="SSH Key")
    #bastion_server_vm = models.ForeignKey(to='virtualization.VirtualMachine', on_delete=models.CASCADE, related_name='bastionservervm', null=False,  blank=True, verbose_name="Bastion VM" )
    tags = taggit.managers.TaggableManager(through='extras.TaggedItem', blank=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'BastionServer'
        verbose_name_plural = 'BastionServers'
        unique_together={('name', 'system_tenant_id') }

    def __str__(self):
        return f'{self.name}'

    def get_absolute_url(self):
        return reverse('plugins:utilities_siteplanner:bastionserver', args=[self.pk])

    def validate_data(self):
        if self.name == '':
            raise ValidationError('Name must be provided for a Bastion Server')
