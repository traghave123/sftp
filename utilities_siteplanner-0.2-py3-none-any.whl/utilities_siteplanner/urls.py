from django.urls import path
from extras.plugins.utils import get_url_extensions
from netbox.views.generic import ObjectChangeLogView, ObjectJournalView
from .automation import *
from nfvi_automation.views import AutomationContextProcessView
from . import views
from .models import ImageRegistry, HttpServer, BastionServer

app_name = 'plugins:utilities_siteplanner'
urlpatterns = [

    path('imageregistrys/', views.ImageRegistryListView.as_view(), name='imageregistry_list'),
    path('imageregistrys/add/', views.ImageRegistryAddView.as_view(), name='imageregistry_add'),
    path('imageregistrys/import/', views.ImageRegistryBulkImportView.as_view(), name='imageregistry_import'),
    path('imageregistrys/delete/', views.ImageRegistryBulkDeleteView.as_view(), name='imageregistry_bulk_delete'),
    path('imageregistrys/<int:pk>/', views.ImageRegistryView.as_view(), name='imageregistry'),
    path('imageregistrys/<int:pk>/edit/', views.ImageRegistryEditView.as_view(), name='imageregistry_edit'),
    path('imageregistrys/<int:pk>/delete/', views.ImageRegistryDeleteView.as_view(), name='imageregistry_delete'),
    path('imageregistrys<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='imageregistry_changelog', kwargs={'model': ImageRegistry}),

    path('httpservers/', views.HttpServerListView.as_view(), name='httpserver_list'),
    path('httpservers/add/', views.HttpServerAddView.as_view(), name='httpserver_add'),
    path('httpservers/import/', views.HttpServerBulkImportView.as_view(), name='httpserver_import'),
    path('httpservers/delete/', views.HttpServerBulkDeleteView.as_view(), name='httpserver_bulk_delete'),
    path('httpservers/<int:pk>/', views.HttpServerView.as_view(), name='httpserver'),
    path('httpservers/<int:pk>/edit/', views.HttpServerEditView.as_view(), name='httpserver_edit'),
    path('httpservers/<int:pk>/delete/', views.HttpServerDeleteView.as_view(), name='httpserver_delete'),
    path('httpservers<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='httpserver_changelog', kwargs={'model': HttpServer}),

    path('bastionservers/', views.BastionServerListView.as_view(), name='bastionserver_list'),
    path('bastionservers/add/', views.BastionServerAddView.as_view(), name='bastionserver_add'),
    path('bastionservers/import/', views.BastionServerBulkImportView.as_view(), name='bastionserver_import'),
    path('bastionservers/delete/', views.BastionServerBulkDeleteView.as_view(), name='bastionserver_bulk_delete'),
    path('bastionservers/<int:pk>/', views.BastionServerView.as_view(), name='bastionserver'),
    path('bastionservers/<int:pk>/edit/', views.BastionServerEditView.as_view(), name='bastionserver_edit'),
    path('bastionservers/<int:pk>/delete/', views.BastionServerDeleteView.as_view(), name='bastionserver_delete'),
    path('bastionservers<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='bastionserver_changelog', kwargs={'model': BastionServer}),

    *get_url_extensions(app_name),
]
