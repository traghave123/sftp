from extras.models import Tag
from django.utils.text import slugify


def create_or_get_tag(name):
    """
    Return the Tag instance for the name given, creates an instance if not found.
    """
    existing = Tag.objects.filter(name=name).first()
    if existing is None:
        return Tag.objects.create(name=name, slug=slugify(name))
    return existing

def create_or_get_tags(*names):
    """
    Return the Tag instance for each name given, creates an instance if not found.
    """
    existing = Tag.objects.filter(name__in=names)
    tags = {}
    for tag in existing:
        tags[tag.name] = tag
    for name in names:
        if name not in tags:
            tags[name] = Tag.objects.create(name=name, slug=slugify(name))
    return tags