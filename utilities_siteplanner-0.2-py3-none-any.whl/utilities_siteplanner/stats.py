from extras.plugins import PluginDashboardStatSection, PluginDashboardStatItem, PlacedPluginDashboardStatItem
from .models import ImageRegistry, HttpServer, BastionServer


stat_extensions = [
    PluginDashboardStatSection(
        label='Utilities',
        icon_class_suffix='layers-triple',
        items=[
            PluginDashboardStatItem(
                label='ImageRegistry',
                perm='utilities_siteplanner.view_imageregistry',
                count_queryset=ImageRegistry.objects
            ),
            PluginDashboardStatItem(
                label='HttpServer',
                perm='utilities_siteplanner.view_httpserver',
                count_queryset=HttpServer.objects
            ),
            PluginDashboardStatItem(
                label='BastionServer',
                perm='utilities_siteplanner.view_bastionserver',
                count_queryset=BastionServer.objects
            )
        ]
    )
]
