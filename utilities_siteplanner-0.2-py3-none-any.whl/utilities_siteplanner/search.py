from extras.plugins import PluginSearchType, PluginSearchGroup, PlacedPluginSearchType
from .filtersets import ImageRegistryFilterSet, HttpServerFilterSet, BastionServerFilterSet
from .models import ImageRegistry, HttpServer, BastionServer
from .tables import ImageRegistryTable, HttpServerTable, BastionServerTable


search_groups = [
    PluginSearchGroup(
        label='Utilities',
        types={
            'imageregistrys': PluginSearchType(
                label='ImageRegistry',
                queryset=ImageRegistry.objects.all(),
                filterset=ImageRegistryFilterSet,
                url='plugins:utilities_siteplanner:imageregistry_list',
                table=ImageRegistryTable
            ),
            'httpservers': PluginSearchType(
                label='HttpServer',
                queryset=HttpServer.objects.all(),
                filterset=HttpServerFilterSet,
                url='plugins:utilities_siteplanner:httpserver_list',
                table=HttpServerTable
            ),
            'bastionservers': PluginSearchType(
                label='BastionServer',
                queryset=BastionServer.objects.all(),
                filterset=BastionServerFilterSet,
                url='plugins:utilities_siteplanner:bastionserver_list',
                table=BastionServerTable
            )
        }
    )
]

search_types = {
    'imageregistry': PlacedPluginSearchType(
        parent_label='Utilities',
        label='ImageRegistry',
        queryset=ImageRegistry.objects.all(),
        filterset=ImageRegistryFilterSet,
        url='plugins:utilities_siteplanner:imageregistry_list',
        table=ImageRegistryTable
    ),
    'httpserver': PlacedPluginSearchType(
        parent_label='Utilities',
        label='HttpServer',
        queryset=HttpServer.objects.all(),
        filterset=HttpServerFilterSet,
        url='plugins:utilities_siteplanner:httpserver_list',
        table=HttpServerTable
    ),
    'bastionserver': PlacedPluginSearchType(
        parent_label='Utilities',
        label='BastionServer',
        queryset=BastionServer.objects.all(),
        filterset=BastionServerFilterSet,
        url='plugins:utilities_siteplanner:bastionserver_list',
        table=BastionServerTable
    )
}
