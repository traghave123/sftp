from extras.plugins import PluginConfig
from graphql import *
from extras.plugins.utils import import_object

class UtilitiesSiteplannerConfig(PluginConfig):
    name = 'utilities_siteplanner'
    verbose_name = 'Utilities'
    description = 'Utilities Plugin: Utilities'
    version = '0.1'
    base_url = 'utilities_siteplanner'
    required_settings = []
    default_settings = {}
    caching_config = {}
    
    def ready(self):
        super().ready()
        from nfvi_automation.models import ObjectTypeAutomationMetadata
        
config = UtilitiesSiteplannerConfig
default_app_config = 'utilities_siteplanner.config'
