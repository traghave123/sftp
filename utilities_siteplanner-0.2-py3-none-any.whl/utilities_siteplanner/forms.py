from django import forms
from netbox.forms import NetBoxModelForm, NetBoxModelCSVForm, NetBoxModelBulkEditForm, NetBoxModelFilterSetForm
from extras.models import Tag
from utilities.forms import (CommentField, CSVModelChoiceField,
                             DynamicModelChoiceField,
                             DynamicModelMultipleChoiceField, JSONField,
                             NumericArrayField, SmallTextarea, TagFilterField, 
                             StaticSelect, StaticSelectMultiple)
from .models import ImageRegistry, HttpServer, BastionServer
#import base64


#
# ImageRegistry
#

class ImageRegistryForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )
    repo_server_password = forms.CharField(widget=forms.PasswordInput(), required=False, label="Password")
    #repo_server_password_byte = str(repo_server_password_temp).encode('ascii')
    #repo_server_password_byte_base64 = base64.b64encode(repo_server_password_byte)
    #repo_server_password = repo_server_password_byte_base64.decode('ascii')
    class Meta:
        model = ImageRegistry
        fields = [
            'name',
            'description',
            'repo_server_url',
            'repo_server_user',
            'repo_server_password',
            'repo_server_auth',
            'repo_server_email',
            #'repo_server_vm',
            'tags'
        ]


class ImageRegistryFilterForm(NetBoxModelFilterSetForm):
    model = ImageRegistry
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class ImageRegistryCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = ImageRegistry
        fields = [
            'name',
            'description',
            'repo_server_url',
            'repo_server_user',
            'repo_server_password',
            'repo_server_auth',
            'repo_server_email',
            #'repo_server_vm',
            'tags'
        ]


class ImageRegistryBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    ) 
    model = ImageRegistry
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )


#
# HttpServer
#

class HttpServerForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )

    http_password = forms.CharField(widget=forms.PasswordInput(), required=False, label="Password")

    class Meta:
        model = HttpServer
        fields = [
            'name',
            'description',
            'http_base_url',
            'http_root_dir',
            'http_port',
            'http_user',
            'http_password',
            'http_basic_auth',
            #'http_server_vm',
            'tags'
        ]


class HttpServerFilterForm(NetBoxModelFilterSetForm):
    model = HttpServer
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class HttpServerCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = HttpServer
        fields = [
            'name',
            'description',
            'http_base_url',
            'http_root_dir',
            'http_port',
            'http_user',
            'http_password',
            'http_basic_auth',
            #'http_server_vm',
            'tags'
        ]


class HttpServerBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    )
    model = HttpServer
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )


#
# BastionServer
#

class BastionServerForm(NetBoxModelForm):
    tags = DynamicModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False
    )

    bastion_ssh_password = forms.CharField(widget=forms.PasswordInput(), required=False, label="Password")
    bastion_ssh_key = forms.CharField(widget=forms.PasswordInput(), required=False, label="SSH Key")

    class Meta:
        model = BastionServer
        fields = [
            'name',
            'description',
            'bastion_ssh_ip',
            'bastion_ssh_port',
            'bastion_ssh_user',
            'bastion_ssh_password',
            'bastion_ssh_auth',
            'bastion_ssh_key',
            #'bastion_server_vm',
            'tags'
        ]


class BastionServerFilterForm(NetBoxModelFilterSetForm):
    model = BastionServer
    fieldsets = (
        ('None', ('q', 'tag', ''))
    )
    tag = TagFilterField(model)


class BastionServerCSVForm(NetBoxModelCSVForm):
    class Meta:
        model = BastionServer
        fields = [
            'name',
            'description',
            'bastion_ssh_ip',
            'bastion_ssh_port',
            'bastion_ssh_user',
            'bastion_ssh_password',
            'bastion_ssh_auth',
            'bastion_ssh_key',
            #'bastion_server_vm',
            'tags'
        ]


class BastionServerBulkEditForm(NetBoxModelBulkEditForm):
    comments = CommentField(
        widget=SmallTextarea,
        label='Comments'
    )
    model = BastionServer
    fieldsets = (
        (None, ('comments')),
    )
    nullable_fields = (
        'comments',
    )
