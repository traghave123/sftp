from oauth.plugins.permissions import OAuthPermissionExtension
from .models import *

class UtilitiesOAuthPermissionExtensions(OAuthPermissionExtension):
  
    def add_to_cloud_read_perm(self):
      return [ ImageRegistry, HttpServer, BastionServer]

    def add_to_cloud_write_perm(self):
      return [ ImageRegistry, HttpServer, BastionServer]
      

permission_extensions = UtilitiesOAuthPermissionExtensions()
